import {
  Box,
  Paper,
  Typography,
  TextField,
  List,
  ListItemButton,
  ListItemText,
  Divider,
  Stack,
  Button,
  Chip,
  CircularProgress,
  Avatar,
  IconButton,
  Badge
} from '@mui/material';
import { Search as SearchIcon, Send as SendIcon, Refresh as RefreshIcon } from '@mui/icons-material';
import { useEffect, useMemo, useState } from 'react';
import { toast } from 'react-toastify';
import api from '../../services/api';

type SavedReply = {
  id: number;
  shortcut: string;
  message: string;
};

type ConversationItem = {
  contactId: number;
  name: string;
  number: string;
  lastMessage?: string;
  updatedAt?: string;
  ticketCount: number;
  statuses: string[];
};

const Conversations = () => {
  const [tickets, setTickets] = useState<any[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(true);
  const [selectedConv, setSelectedConv] = useState<ConversationItem | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [search, setSearch] = useState('');
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [savedReplies, setSavedReplies] = useState<SavedReply[]>([]);

  const fmtTime = (date?: string) => {
    if (!date) return '';
    const d = new Date(date);
    if (Number.isNaN(d.getTime())) return '';
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const fetchTickets = async () => {
    setLoadingTickets(true);
    try {
      const { data } = await api.get('/tickets');
      setTickets(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
      toast.error('Error al cargar conversaciones');
      setTickets([]);
    } finally {
      setLoadingTickets(false);
    }
  };

  const fetchConversationMessages = async (contactId: number) => {
    setLoadingMessages(true);
    try {
      const { data: tks } = await api.get('/tickets', { params: { contactId } });
      const list = Array.isArray(tks) ? tks : [];

      const all = await Promise.all(
        list.map(async (t: any) => {
          const { data: msgs } = await api.get(`/messages/${t.id}`);
          const arr = Array.isArray(msgs) ? msgs : [];
          return arr.map((m: any) => ({ ...m, ticketId: t.id, ticketStatus: t.status }));
        })
      );

      const merged = all.flat();
      merged.sort((a: any, b: any) => {
        const da = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const db = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return da - db;
      });

      setMessages(merged);
    } catch (e) {
      console.error(e);
      toast.error('Error al cargar mensajes');
      setMessages([]);
    } finally {
      setLoadingMessages(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  useEffect(() => {
    const id = setInterval(() => {
      fetchTickets();
    }, 10000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get('/saved-replies');
        setSavedReplies(Array.isArray(data) ? data : []);
      } catch {
        setSavedReplies([]);
      }
    })();
  }, []);

  const conversations: ConversationItem[] = useMemo(() => {
    const byContact = new Map<number, ConversationItem>();

    for (const t of tickets) {
      const contactId = t.contactId || t.contact?.id;
      if (!contactId) continue;

      const name = t.contact?.name || 'Sin nombre';
      const number = t.contact?.number || '';
      const updatedAt = t.updatedAt || t.createdAt;
      const current = byContact.get(contactId);
      const lastMessage = t.lastMessage || current?.lastMessage || '';

      if (!current) {
        byContact.set(contactId, {
          contactId,
          name,
          number,
          lastMessage,
          updatedAt,
          ticketCount: 1,
          statuses: [t.status].filter(Boolean)
        });
      } else {
        const curTs = current.updatedAt ? new Date(current.updatedAt).getTime() : 0;
        const nextTs = updatedAt ? new Date(updatedAt).getTime() : 0;
        const next: ConversationItem = {
          ...current,
          ticketCount: current.ticketCount + 1,
          statuses: Array.from(new Set([...(current.statuses || []), t.status].filter(Boolean)))
        };
        if (nextTs >= curTs) {
          next.updatedAt = updatedAt;
          if (t.lastMessage) next.lastMessage = t.lastMessage;
          next.name = name || next.name;
          next.number = number || next.number;
        }
        byContact.set(contactId, next);
      }
    }

    return Array.from(byContact.values()).sort((a, b) => {
      const da = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
      const db = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
      return db - da;
    });
  }, [tickets]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return conversations;
    return conversations.filter((c) =>
      [c.name || '', c.number || '', c.lastMessage || ''].some((x) => x.toLowerCase().includes(q))
    );
  }, [conversations, search]);

  const statusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'success';
      case 'pending':
        return 'warning';
      case 'closed':
        return 'default';
      default:
        return 'default';
    }
  };

  const handleSelect = async (c: ConversationItem) => {
    setSelectedConv(c);
    await fetchConversationMessages(c.contactId);
  };

  const handleSend = async () => {
    if (!selectedConv?.contactId || !text.trim()) return;
    setSending(true);
    try {
      await api.post(`/contacts/${selectedConv.contactId}/message`, { body: text.trim() });
      setText('');
      await fetchTickets();
      await fetchConversationMessages(selectedConv.contactId);
    } catch (e: any) {
      console.error(e);
      toast.error(e?.response?.data?.error || 'Error al enviar mensaje');
    } finally {
      setSending(false);
    }
  };

  return (
    <Box sx={{ height: 'calc(100vh - 140px)' }}>
      <Paper
        sx={{
          height: '100%',
          display: 'flex',
          overflow: 'hidden',
          borderRadius: 3,
          bgcolor: '#0b141a',
          border: '1px solid rgba(255,255,255,0.08)',
          boxShadow: '0 12px 40px rgba(0,0,0,0.45)'
        }}
      >
        <Box
          sx={{
            width: { xs: '100%', md: 360 },
            borderRight: { md: '1px solid #202c33' },
            bgcolor: '#111b21',
            display: selectedConv ? { xs: 'none', md: 'block' } : 'block'
          }}
        >
          <Box sx={{ p: 1.5, bgcolor: '#202c33', borderBottom: '1px solid #2a3942' }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 700, color: '#e9edef' }}>
              Conversaciones
            </Typography>
          </Box>

          <Box sx={{ p: 1, bgcolor: '#111b21' }}>
            <TextField
              fullWidth
              size="small"
              placeholder="Buscar o iniciar chat"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              InputProps={{
                startAdornment: <SearchIcon sx={{ mr: 1, color: '#8696a0' }} fontSize="small" />
              }}
              sx={{
                '& .MuiInputBase-root': {
                  bgcolor: '#202c33',
                  color: '#d1d7db',
                  borderRadius: 2
                },
                '& .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent' },
                '& .MuiInputBase-root:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#2a3942' },
                '& .MuiInputBase-root.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#00a884' }
              }}
            />
          </Box>
          <Divider sx={{ borderColor: '#2a3942' }} />

          {loadingTickets ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 3 }}>
              <CircularProgress size={24} sx={{ color: '#00a884' }} />
            </Box>
          ) : filtered.length === 0 ? (
            <Typography variant="body2" sx={{ p: 2, color: '#8696a0' }}>
              No hay conversaciones.
            </Typography>
          ) : (
            <List dense sx={{ maxHeight: 'calc(100% - 120px)', overflow: 'auto', p: 0 }}>
              {filtered.map((c) => (
                <ListItemButton
                  key={c.contactId}
                  selected={selectedConv?.contactId === c.contactId}
                  onClick={() => handleSelect(c)}
                  sx={{
                    py: 1.2,
                    px: 1.5,
                    borderBottom: '1px solid #202c33',
                    '&.Mui-selected': { bgcolor: '#2a3942' },
                    '&:hover': { bgcolor: '#202c33' }
                  }}
                >
                  <Avatar sx={{ width: 40, height: 40, mr: 1.2, bgcolor: '#3b4a54', color: '#e9edef' }}>
                    {(c.name || '?').slice(0, 1).toUpperCase()}
                  </Avatar>
                  <ListItemText
                    primary={
                      <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="body2" sx={{ fontWeight: 600, color: '#e9edef' }}>
                          {c.name}
                        </Typography>
                        <Typography variant="caption" sx={{ color: '#8696a0' }}>
                          {fmtTime(c.updatedAt)}
                        </Typography>
                      </Stack>
                    }
                    secondary={
                      <Stack direction="row" justifyContent="space-between" alignItems="center">
                        <Typography variant="caption" noWrap sx={{ maxWidth: 180, color: '#8696a0' }}>
                          {c.lastMessage || c.number}
                        </Typography>
                        <Badge
                          color="success"
                          badgeContent={c.ticketCount > 99 ? '99+' : c.ticketCount}
                          sx={{ '& .MuiBadge-badge': { bgcolor: '#00a884', color: '#0b141a' } }}
                        />
                      </Stack>
                    }
                  />
                </ListItemButton>
              ))}
            </List>
          )}
        </Box>

        <Box
          sx={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            bgcolor: '#0b141a',
            backgroundImage:
              'radial-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), radial-gradient(rgba(255,255,255,0.02) 1px, transparent 1px)',
            backgroundPosition: '0 0, 20px 20px',
            backgroundSize: '40px 40px'
          }}
        >
          {!selectedConv ? (
            <Box sx={{ m: 'auto', textAlign: 'center', color: '#8696a0' }}>
              <Typography variant="h6" sx={{ color: '#e9edef' }}>
                Seleccioná una conversación
              </Typography>
              <Typography variant="body2">Tema oscuro estilo WhatsApp aplicado</Typography>
            </Box>
          ) : (
            <>
              <Box
                sx={{
                  p: 1.2,
                  bgcolor: '#202c33',
                  borderBottom: '1px solid #2a3942',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
              >
                <Stack direction="row" spacing={1.2} alignItems="center">
                  <Avatar sx={{ bgcolor: '#3b4a54', color: '#e9edef' }}>
                    {(selectedConv.name || '?').slice(0, 1).toUpperCase()}
                  </Avatar>
                  <Box>
                    <Typography variant="body2" sx={{ fontWeight: 600, color: '#e9edef' }}>
                      {selectedConv.name}
                    </Typography>
                    <Typography variant="caption" sx={{ color: '#8696a0' }}>
                      {selectedConv.number}
                    </Typography>
                  </Box>
                </Stack>
                <Stack direction="row" spacing={0.6}>
                  {selectedConv.statuses.slice(0, 2).map((s) => (
                    <Chip key={s} size="small" label={s} color={statusColor(s)} />
                  ))}
                  <IconButton onClick={() => fetchConversationMessages(selectedConv.contactId)} size="small" sx={{ color: '#e9edef' }}>
                    <RefreshIcon fontSize="small" />
                  </IconButton>
                </Stack>
              </Box>

              <Stack spacing={1} sx={{ flex: 1, overflow: 'auto', p: 2 }}>
                {loadingMessages ? (
                  <Box sx={{ display: 'flex', justifyContent: 'center', py: 3 }}>
                    <CircularProgress size={24} sx={{ color: '#00a884' }} />
                  </Box>
                ) : messages.length === 0 ? (
                  <Typography variant="body2" sx={{ color: '#8696a0' }}>
                    No hay mensajes.
                  </Typography>
                ) : (
                  messages.map((m) => (
                    <Box
                      key={m.id || `${m.createdAt}-${m.body}`}
                      sx={{ display: 'flex', justifyContent: m.fromMe ? 'flex-end' : 'flex-start' }}
                    >
                      <Paper
                        variant="outlined"
                        sx={{
                          p: 1.1,
                          px: 1.2,
                          maxWidth: '78%',
                          borderRadius: 2,
                          bgcolor: m.fromMe ? '#005c4b' : '#202c33',
                          color: '#e9edef',
                          borderColor: 'rgba(255,255,255,0.12)'
                        }}
                      >
                        <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
                          {m.body}
                        </Typography>
                        <Typography
                          variant="caption"
                          sx={{ mt: 0.5, display: 'block', textAlign: 'right', color: 'rgba(233,237,239,0.72)' }}
                        >
                          {fmtTime(m.createdAt)}
                        </Typography>
                      </Paper>
                    </Box>
                  ))
                )}
              </Stack>

              <Box sx={{ p: 1.2, bgcolor: '#202c33', borderTop: '1px solid #2a3942' }}>
                {savedReplies.length > 0 && (
                  <Stack direction="row" spacing={0.8} sx={{ mb: 1, overflowX: 'auto', pb: 0.5 }}>
                    {savedReplies.slice(0, 8).map((r) => (
                      <Chip
                        key={r.id}
                        size="small"
                        label={r.shortcut}
                        onClick={() => setText((t) => (t ? `${t} ${r.message}` : r.message))}
                        sx={{ bgcolor: '#2a3942', color: '#e9edef', border: '1px solid #3b4a54' }}
                      />
                    ))}
                  </Stack>
                )}
                <Stack direction="row" spacing={1}>
                  <TextField
                    fullWidth
                    multiline
                    maxRows={4}
                    minRows={1}
                    placeholder="Escribí un mensaje"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    disabled={sending}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSend();
                      }
                    }}
                    sx={{
                      '& .MuiInputBase-root': {
                        bgcolor: '#2a3942',
                        color: '#e9edef',
                        borderRadius: 3
                      },
                      '& .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent' },
                      '& .MuiInputBase-root:hover .MuiOutlinedInput-notchedOutline': { borderColor: '#3b4a54' },
                      '& .MuiInputBase-root.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: '#00a884' }
                    }}
                  />
                  <Button
                    variant="contained"
                    onClick={handleSend}
                    disabled={sending || !text.trim()}
                    sx={{ minWidth: 54, borderRadius: '50%', bgcolor: '#00a884', '&:hover': { bgcolor: '#029b7b' } }}
                  >
                    {sending ? <CircularProgress size={20} color="inherit" /> : <SendIcon />}
                  </Button>
                </Stack>
              </Box>
            </>
          )}
        </Box>
      </Paper>
    </Box>
  );
};

export default Conversations;

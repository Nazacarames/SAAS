import { Typography, Box, Grid, Paper, Card, CardContent } from '@mui/material';
import {
    Chat as ChatIcon,
    Contacts as ContactsIcon,
    WhatsApp as WhatsAppIcon,
    CheckCircle as CheckCircleIcon
} from '@mui/icons-material';

const Dashboard = () => {
    const stats = [
        { title: 'Tickets Abiertos', value: '0', icon: <ChatIcon fontSize="large" />, color: '#3b82f6' },
        { title: 'Contactos', value: '0', icon: <ContactsIcon fontSize="large" />, color: '#8b5cf6' },
        { title: 'Conexiones', value: '0', icon: <WhatsAppIcon fontSize="large" />, color: '#10b981' },
        { title: 'Resueltos Hoy', value: '0', icon: <CheckCircleIcon fontSize="large" />, color: '#f59e0b' },
    ];

    return (
        <Box>
            <Typography variant="h4" gutterBottom>
                Dashboard
            </Typography>
            <Grid container spacing={3} sx={{ mt: 2 }}>
                {stats.map((stat, index) => (
                    <Grid item xs={12} sm={6} md={3} key={index}>
                        <Card>
                            <CardContent>
                                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                    <Box>
                                        <Typography color="text.secondary" gutterBottom>
                                            {stat.title}
                                        </Typography>
                                        <Typography variant="h4">
                                            {stat.value}
                                        </Typography>
                                    </Box>
                                    <Box sx={{ color: stat.color }}>
                                        {stat.icon}
                                    </Box>
                                </Box>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}
            </Grid>
            <Paper sx={{ mt: 3, p: 3 }}>
                <Typography variant="h6" gutterBottom>
                    Bienvenido al Sistema de Atención WhatsApp
                </Typography>
                <Typography variant="body1">
                    Utiliza el menú lateral para navegar entre las diferentes secciones.
                </Typography>
            </Paper>
        </Box>
    );
};

export default Dashboard;

import {
  Typography,
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  CircularProgress,
  IconButton
} from '@mui/material';
import { Add as AddIcon, Delete as DeleteIcon, QrCode as QrCodeIcon } from '@mui/icons-material';
import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import QRCode from 'react-qr-code';
import api from '../../services/api';
import { socketConnection } from '../../services/socket';

interface WhatsAppConnection {
  id: number;
  name: string;
  status: string;
  qrcode?: string;
  battery?: number;
  isDefault: boolean;
}

const Connections = () => {
  const [connections, setConnections] = useState<WhatsAppConnection[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [qrDialogOpen, setQrDialogOpen] = useState(false);
  const [connectionName, setConnectionName] = useState('');
  const [creating, setCreating] = useState(false);
  const [selectedConnection, setSelectedConnection] = useState<WhatsAppConnection | null>(null);
  const [qrLoading, setQrLoading] = useState(false);

  useEffect(() => {
    fetchConnections();

    const socket = socketConnection;
    return () => {
      socket.off();
    };
  }, []);

  useEffect(() => {
    const socket = socketConnection;

    connections.forEach((conn) => {
      socket.off(`whatsapp-${conn.id}`);
      socket.on(`whatsapp-${conn.id}`, (data: any) => {
        if (data.action === 'update') {
          const { session } = data;

          setConnections((prev) => prev.map((c) => (c.id === conn.id ? { ...c, ...session } : c)));

          if (selectedConnection && selectedConnection.id === conn.id) {
            setSelectedConnection((prev) => (prev ? { ...prev, ...session } : null));
          }
        }
      });
    });
  }, [connections, selectedConnection]);

  const fetchConnections = async () => {
    try {
      const { data } = await api.get('/whatsapps');
      setConnections(data);
    } catch (error) {
      console.error('Error fetching connections:', error);
      toast.error('Error al cargar conexiones');
    } finally {
      setLoading(false);
    }
  };

  const fetchConnection = async (id: number) => {
    const { data } = await api.get(`/whatsapps/${id}`);
    return data as WhatsAppConnection;
  };

  const handleOpen = () => {
    setConnectionName('');
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setCreating(false);
  };

  const handleCreateConnection = async () => {
    if (!connectionName.trim()) {
      toast.error('Por favor ingresa un nombre para la conexión');
      return;
    }

    setCreating(true);
    try {
      const { data: newConnection } = await api.post('/whatsapps', {
        name: connectionName,
        isDefault: connections.length === 0
      });

      toast.success('Conexión creada exitosamente');
      handleClose();
      fetchConnections();

      setTimeout(async () => {
        try {
          await api.post(`/sessions/${newConnection.id}`);
          const fresh = await fetchConnection(newConnection.id);
          setSelectedConnection(fresh);
          setQrDialogOpen(true);
        } catch (error: any) {
          console.error('Error starting session:', error);
          toast.error('Error al iniciar sesión');
        }
      }, 500);
    } catch (error: any) {
      console.error('Error creating connection:', error);
      toast.error(error.response?.data?.message || 'Error al crear conexión');
    } finally {
      setCreating(false);
    }
  };

  const handleShowQR = async (connection: WhatsAppConnection) => {
    setQrLoading(true);
    setSelectedConnection(connection);
    setQrDialogOpen(true);

    try {
      const fresh = await fetchConnection(connection.id);
      setSelectedConnection(fresh);

      if (fresh.status === 'DISCONNECTED') {
        await api.post(`/sessions/${connection.id}`);
        toast.info('Iniciando sesión...');
      }
    } catch (error) {
      console.error('Error showing QR:', error);
      toast.error('Error al abrir QR');
    } finally {
      setQrLoading(false);
    }
  };

  const handleCloseQR = () => {
    setQrDialogOpen(false);
    setSelectedConnection(null);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm('¿Estás seguro de eliminar esta conexión?')) {
      try {
        await api.delete(`/whatsapps/${id}`);
        toast.success('Conexión eliminada');
        fetchConnections();
      } catch (error) {
        console.error('Error deleting connection:', error);
        toast.error('Error al eliminar conexión');
      }
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'CONNECTED':
        return 'success';
      case 'DISCONNECTED':
        return 'error';
      case 'OPENING':
        return 'info';
      case 'qrcode':
        return 'warning';
      default:
        return 'default';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'CONNECTED':
        return 'Conectado';
      case 'DISCONNECTED':
        return 'Desconectado';
      case 'OPENING':
        return 'Abriendo';
      case 'qrcode':
        return 'Esperando QR';
      default:
        return status;
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h4">Conexiones WhatsApp</Typography>
        <Button variant="contained" startIcon={<AddIcon />} onClick={handleOpen}>
          Nueva Conexión
        </Button>
      </Box>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Nombre</TableCell>
                <TableCell>Estado</TableCell>
                <TableCell>Batería</TableCell>
                <TableCell>Predeterminada</TableCell>
                <TableCell>Acciones</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    Cargando...
                  </TableCell>
                </TableRow>
              ) : connections.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    No hay conexiones disponibles
                  </TableCell>
                </TableRow>
              ) : (
                connections.map((conn) => (
                  <TableRow key={conn.id}>
                    <TableCell>{conn.id}</TableCell>
                    <TableCell>{conn.name}</TableCell>
                    <TableCell>
                      <Chip label={getStatusLabel(conn.status)} color={getStatusColor(conn.status)} size="small" />
                    </TableCell>
                    <TableCell>{conn.battery || 'N/A'}%</TableCell>
                    <TableCell>{conn.isDefault ? 'Sí' : 'No'}</TableCell>
                    <TableCell>
                      <IconButton size="small" onClick={() => handleShowQR(conn)} color="primary">
                        <QrCodeIcon />
                      </IconButton>
                      <IconButton size="small" onClick={() => handleDelete(conn.id)} color="error">
                        <DeleteIcon />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>Nueva Conexión WhatsApp</DialogTitle>
        <DialogContent>
          <Box sx={{ pt: 2 }}>
            <TextField
              label="Nombre de la Conexión"
              fullWidth
              value={connectionName}
              onChange={(e) => setConnectionName(e.target.value)}
              placeholder="Ej: WhatsApp Principal"
              disabled={creating}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} disabled={creating}>
            Cancelar
          </Button>
          <Button
            onClick={handleCreateConnection}
            variant="contained"
            disabled={creating}
            startIcon={creating && <CircularProgress size={20} />}
          >
            {creating ? 'Creando...' : 'Crear'}
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={qrDialogOpen} onClose={handleCloseQR} maxWidth="sm" fullWidth>
        <DialogTitle>{selectedConnection?.name} — Conexión</DialogTitle>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2, py: 3 }}>
            {selectedConnection?.status === 'CONNECTED' ? (
              <Box sx={{ textAlign: 'center' }}>
                <Chip label="Conectado" color="success" />
                <Typography sx={{ mt: 2 }}>¡Conectado exitosamente!</Typography>
              </Box>
            ) : selectedConnection?.qrcode ? (
              <>
                <QRCode value={selectedConnection.qrcode} size={300} />
                <Typography variant="body2" color="text.secondary" align="center">
                  Escanea este código QR con WhatsApp en tu teléfono
                </Typography>
              </>
            ) : (
              <Box sx={{ textAlign: 'center' }}>
                {(qrLoading || selectedConnection?.status === 'OPENING' || selectedConnection?.status === 'qrcode') && (
                  <CircularProgress size={60} />
                )}
                <Typography sx={{ mt: 2 }}>
                  {selectedConnection?.status === 'DISCONNECTED'
                    ? 'Desconectado. Iniciando sesión…'
                    : 'Generando código QR…'}
                </Typography>
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseQR}>Cerrar</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Connections;

import {
  Typography,
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  Stack,
  Chip,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Divider
} from "@mui/material";
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Send as SendIcon,
  OpenInNew as OpenInNewIcon
} from "@mui/icons-material";
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../../services/api";
import { useAuth } from "../../context/Auth/AuthContext";

type LeadStatus = "unread" | "read" | "waiting";

interface Tag {
  id: number;
  name: string;
  color?: string;
}

interface User {
  id: number;
  name: string;
  email: string;
}

interface Webhook {
  id: number;
  name: string;
  url: string;
  event: string;
  active: boolean;
}

interface Lead {
  id: number;
  name: string;
  number: string;
  email: string;
  source?: string;
  leadStatus?: LeadStatus;
  assignedUserId?: number | null;
  assignedUser?: User | null;
  inactivityMinutes?: number;
  inactivityWebhookId?: number | null;
  tags?: Tag[];
  createdAt: string;
  updatedAt: string;
}

const statusLabel: Record<LeadStatus, string> = {
  unread: "No leído",
  read: "Leído",
  waiting: "Esperando respuesta"
};

const statusColor: Record<LeadStatus, any> = {
  unread: "info",
  read: "default",
  waiting: "warning"
};

const Leads = () => {
  const navigate = useNavigate();
    const { user } = useAuth();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);

  const [users, setUsers] = useState<User[]>([]);
  const [allTags, setAllTags] = useState<Tag[]>([]);
  const [webhooks, setWebhooks] = useState<Webhook[]>([]);

  const [filterStatus, setFilterStatus] = useState<LeadStatus | "all">("all");
  const [filterAssignee, setFilterAssignee] = useState<number | "all" | "unassigned" | "me">("all");

  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState<Lead | null>(null);

  const [name, setName] = useState("");
  const [number, setNumber] = useState("");
  const [email, setEmail] = useState("");
  const [source, setSource] = useState("");
  const [leadStatus, setLeadStatus] = useState<LeadStatus>("unread");
  const [assignedUserId, setAssignedUserId] = useState<number | "">("");
  const [inactivityMinutes, setInactivityMinutes] = useState<number>(30);
  const [inactivityWebhookId, setInactivityWebhookId] = useState<number | "">("");
  const [tagInput, setTagInput] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  const [msgOpen, setMsgOpen] = useState(false);
  const [msgSending, setMsgSending] = useState(false);
  const [msgLead, setMsgLead] = useState<Lead | null>(null);
  const [msgText, setMsgText] = useState("");

  const fetchLeads = async (status?: string) => {
    const params: any = {};
    if (status) params.status = status;
    if (filterAssignee !== "all") {
      if (filterAssignee === "unassigned") params.assignedUserId = "null";
      else if (filterAssignee === "me") params.assignedUserId = user?.id;
      else params.assignedUserId = filterAssignee;
    }

    try {
      const { data } = await api.get("/contacts", { params: Object.keys(params).length ? params : undefined });
      setLeads(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error("Error fetching leads:", error);
      toast.error("Error al cargar leads");
    } finally {
      setLoading(false);
    }
  };

  const fetchMeta = async () => {
    try {
      const [u, t, w] = await Promise.all([
        api.get("/users"),
        api.get("/tags"),
        api.get("/webhooks")
      ]);
      setUsers(Array.isArray(u.data) ? u.data : []);
      setAllTags(Array.isArray(t.data) ? t.data : []);
      setWebhooks(Array.isArray(w.data) ? w.data : []);
    } catch (e) {
      // Non-blocking
      console.warn("Meta fetch warning:", e);
    }
  };

  useEffect(() => {
    fetchMeta();
  }, []);

  useEffect(() => {
    setLoading(true);
    fetchLeads(filterStatus === "all" ? undefined : filterStatus);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterStatus, filterAssignee]);

  const resetForm = () => {
    setName("");
    setNumber("");
    setEmail("");
    setSource("");
    setLeadStatus("unread");
    setAssignedUserId("");
    setInactivityMinutes(30);
    setInactivityWebhookId("");
    setSelectedTags([]);
    setTagInput("");
    setEditing(null);
  };

  const handleOpenCreate = () => {
    resetForm();
    setOpen(true);
  };

  const handleOpenEdit = (c: Lead) => {
    setEditing(c);
    setName(c.name || "");
    setNumber(c.number || "");
    setEmail(c.email || "");
    setSource(c.source || "");
    setLeadStatus((c.leadStatus as LeadStatus) || "unread");
    setAssignedUserId(c.assignedUserId ?? "");
    setInactivityMinutes(typeof c.inactivityMinutes === "number" ? c.inactivityMinutes : 30);
    setInactivityWebhookId(c.inactivityWebhookId ?? "");
    setSelectedTags((c.tags || []).map((t) => t.name));
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSaving(false);
  };

  const addTag = () => {
    const v = tagInput.trim();
    if (!v) return;
    if (selectedTags.includes(v)) {
      setTagInput("");
      return;
    }
    setSelectedTags([...selectedTags, v]);
    setTagInput("");
  };

  const removeTag = (name: string) => {
    setSelectedTags(selectedTags.filter((t) => t !== name));
  };

  const handleSave = async () => {
    if (!name.trim()) {
      toast.error("El nombre es obligatorio");
      return;
    }
    if (!number.trim()) {
      toast.error("El número es obligatorio");
      return;
    }

    setSaving(true);
    try {
      const payload: any = {
        name: name.trim(),
        number: number.trim(),
        email: email.trim(),
        source: source.trim() || null,
        leadStatus,
        assignedUserId: assignedUserId === "" ? null : assignedUserId,
        inactivityMinutes: Number(inactivityMinutes || 0) || 30,
        inactivityWebhookId: inactivityWebhookId === "" ? null : inactivityWebhookId,
        tags: selectedTags
      };

      if (editing) {
        await api.put(`/contacts/${editing.id}`, payload);
        toast.success("Lead actualizado");
      } else {
        await api.post("/contacts", payload);
        toast.success("Lead creado");
      }
      handleClose();
      fetchLeads(filterStatus === "all" ? undefined : filterStatus);
    } catch (error: any) {
      console.error("Error saving lead:", error);
      toast.error(error?.response?.data?.error || "Error al guardar lead");
    } finally {
      setSaving(false);
    }
  };

  const openTicket = async (lead: Lead) => {
    try {
      const { data } = await api.get(`/tickets?contactId=${lead.id}`);
      const list = Array.isArray(data) ? data : [];
      const ticket = list[0];
      if (!ticket?.id) {
        toast.info("Este lead todavía no tiene ticket");
        return;
      }
      navigate(`/tickets?ticketId=${ticket.id}`);
    } catch (e) {
      console.error("Error opening ticket:", e);
      toast.error("Error al abrir ticket");
    }
  };

  const handleDelete = async (c: Lead) => {
    if (!window.confirm(`¿Eliminar lead "${c.name}"?`)) return;

    try {
      await api.delete(`/contacts/${c.id}`);
      toast.success("Lead eliminado");
      fetchLeads(filterStatus === "all" ? undefined : filterStatus);
    } catch (error) {
      console.error("Error deleting lead:", error);
      toast.error("Error al eliminar lead");
    }
  };

  const openSend = (c: Lead) => {
    setMsgLead(c);
    setMsgText("");
    setMsgOpen(true);
  };

  const closeSend = () => {
    setMsgOpen(false);
    setMsgSending(false);
    setMsgLead(null);
    setMsgText("");
  };

  const handleSend = async () => {
    if (!msgLead?.id) return;
    if (!msgText.trim()) return;

    setMsgSending(true);
    try {
      const { data } = await api.post(`/contacts/${msgLead.id}/message`, { body: msgText.trim() });
      toast.success("Mensaje enviado");
      closeSend();
      if (data?.ticket?.id) navigate(`/tickets?ticketId=${data.ticket.id}`);
      fetchLeads(filterStatus === "all" ? undefined : filterStatus);
    } catch (error: any) {
      console.error("Error sending lead message:", error);
      toast.error(error?.response?.data?.error || "Error al enviar mensaje");
    } finally {
      setMsgSending(false);
    }
  };

  const filtered = useMemo(() => leads, [leads]);

  return (
    <Box>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2, gap: 2, flexWrap: "wrap" }}>
        <Box>
          <Typography variant="h4">Leads</Typography>
          <Typography variant="body2" color="text.secondary">
            Clasificá por estado, asigná usuarios, agregá etiquetas y timers de inactividad.
          </Typography>
        </Box>

        <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
          <FormControl size="small" sx={{ minWidth: 220 }}>
            <InputLabel>Estado</InputLabel>
            <Select
              label="Estado"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
            >
              <MenuItem value="all">Todos</MenuItem>
              <MenuItem value="unread">No leídos</MenuItem>
              <MenuItem value="waiting">Esperando respuesta</MenuItem>
              <MenuItem value="read">Leídos</MenuItem>
            </Select>
          </FormControl>

          <FormControl size="small" sx={{ minWidth: 240 }}>
              <InputLabel>Asignado</InputLabel>
              <Select
                label="Asignado"
                value={filterAssignee}
                onChange={(e) => setFilterAssignee(e.target.value as any)}
              >
                <MenuItem value="all">Todos</MenuItem>
                <MenuItem value="me">Mis leads</MenuItem>
                <MenuItem value="unassigned">Sin asignar</MenuItem>
                {users.map((u) => (
                  <MenuItem key={u.id} value={u.id}>
                    {u.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <Button variant="contained" startIcon={<AddIcon />} onClick={handleOpenCreate}>
            Nuevo Lead
          </Button>
        </Stack>
      </Box>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Nombre</TableCell>
                <TableCell>Estado</TableCell>
                <TableCell>Etiquetas</TableCell>
                <TableCell>Asignado</TableCell>
                <TableCell>Número</TableCell>
                <TableCell>Fuente</TableCell>
                <TableCell>Actualizado</TableCell>
                <TableCell align="right">Acciones</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={9} align="center">
                    Cargando...
                  </TableCell>
                </TableRow>
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} align="center">
                    No hay leads
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((c) => {
                  const st = (c.leadStatus || "unread") as LeadStatus;
                  return (
                    <TableRow key={c.id} hover>
                      <TableCell>{c.id}</TableCell>
                      <TableCell>{c.name}</TableCell>
                      <TableCell>
                        <Chip size="small" label={statusLabel[st]} color={statusColor[st]} />
                      </TableCell>
                      <TableCell>
                        <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
                          {(c.tags || []).slice(0, 3).map((t) => (
                            <Chip
                              key={t.id}
                              size="small"
                              label={t.name}
                              sx={{ borderColor: t.color || "#1F2A44" }}
                              variant="outlined"
                            />
                          ))}
                          {(c.tags || []).length > 3 && <Chip size="small" label={`+${(c.tags || []).length - 3}`} variant="outlined" />}
                        </Stack>
                      </TableCell>
                      <TableCell>{c.assignedUser?.name || "-"}</TableCell>
                      <TableCell>{c.number}</TableCell>
                      <TableCell>{c.source || "-"}</TableCell>
                      <TableCell>{c.updatedAt ? new Date(c.updatedAt).toLocaleString() : "-"}</TableCell>
                      <TableCell align="right">
                        <IconButton size="small" onClick={() => openTicket(c)} color="info" title="Abrir ticket">
                          <OpenInNewIcon />
                        </IconButton>
                        <IconButton size="small" onClick={() => openSend(c)} color="success" title="Enviar mensaje">
                          <SendIcon />
                        </IconButton>
                        <IconButton size="small" onClick={() => handleOpenEdit(c)} color="primary" title="Editar">
                          <EditIcon />
                        </IconButton>
                        <IconButton size="small" onClick={() => handleDelete(c)} color="error" title="Eliminar">
                          <DeleteIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={open} onClose={handleClose} fullWidth maxWidth="md">
        <DialogTitle>{editing ? "Editar Lead" : "Nuevo Lead"}</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Stack direction={{ xs: "column", md: "row" }} spacing={2}>
              <TextField label="Nombre" fullWidth value={name} onChange={(e) => setName(e.target.value)} />
              <TextField label="Número" fullWidth value={number} onChange={(e) => setNumber(e.target.value)} />
            </Stack>

            <Stack direction={{ xs: "column", md: "row" }} spacing={2}>
              <TextField label="Email" fullWidth value={email} onChange={(e) => setEmail(e.target.value)} />
              <TextField label="Fuente" fullWidth value={source} onChange={(e) => setSource(e.target.value)} placeholder="meta_ads, botpress, manual..." />
            </Stack>

            <Stack direction={{ xs: "column", md: "row" }} spacing={2}>
              <FormControl fullWidth>
                <InputLabel>Estado</InputLabel>
                <Select label="Estado" value={leadStatus} onChange={(e) => setLeadStatus(e.target.value as LeadStatus)}>
                  <MenuItem value="unread">No leído</MenuItem>
                  <MenuItem value="waiting">Esperando respuesta</MenuItem>
                  <MenuItem value="read">Leído</MenuItem>
                </Select>
              </FormControl>

              <FormControl fullWidth>
                <InputLabel>Asignado a</InputLabel>
                <Select label="Asignado a" value={assignedUserId} onChange={(e) => setAssignedUserId(e.target.value as any)}>
                  <MenuItem value="">Sin asignar</MenuItem>
                  {users.map((u) => (
                    <MenuItem key={u.id} value={u.id}>
                      {u.name} ({u.email})
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Stack>

            <Divider />

            <Typography variant="subtitle1">Etiquetas</Typography>
            <Stack direction={{ xs: "column", md: "row" }} spacing={1} alignItems={{ md: "center" }}>
              <TextField
                label="Agregar etiqueta"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addTag();
                  }
                }}
                fullWidth
                helperText={allTags.length ? `Sugerencias: ${allTags.slice(0, 8).map((t) => t.name).join(", ")}` : ""}
              />
              <Button variant="outlined" onClick={addTag}>
                Agregar
              </Button>
            </Stack>

            <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
              {selectedTags.map((t) => (
                <Chip key={t} label={t} onDelete={() => removeTag(t)} variant="outlined" />
              ))}
            </Stack>

            <Divider />

            <Typography variant="subtitle1">Timer de inactividad → Webhook</Typography>
            <Stack direction={{ xs: "column", md: "row" }} spacing={2}>
              <TextField
                label="Minutos sin interacción"
                type="number"
                value={inactivityMinutes}
                onChange={(e) => setInactivityMinutes(parseInt(e.target.value || "0", 10))}
                fullWidth
              />
              <FormControl fullWidth>
                <InputLabel>Webhook</InputLabel>
                <Select
                  label="Webhook"
                  value={inactivityWebhookId}
                  onChange={(e) => setInactivityWebhookId(e.target.value as any)}
                >
                  <MenuItem value="">Sin webhook</MenuItem>
                  {webhooks
                    .filter((w) => w.active)
                    .map((w) => (
                      <MenuItem key={w.id} value={w.id}>
                        {w.name} ({w.event})
                      </MenuItem>
                    ))}
                </Select>
              </FormControl>
            </Stack>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} disabled={saving}>
            Cancelar
          </Button>
          <Button variant="contained" onClick={handleSave} disabled={saving}>
            {saving ? "Guardando..." : "Guardar"}
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={msgOpen} onClose={closeSend} fullWidth maxWidth="sm">
        <DialogTitle>Enviar mensaje</DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
            A: {msgLead?.name} ({msgLead?.number})
          </Typography>
          <TextField
            label="Mensaje"
            multiline
            minRows={4}
            fullWidth
            value={msgText}
            onChange={(e) => setMsgText(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={closeSend} disabled={msgSending}>
            Cancelar
          </Button>
          <Button variant="contained" onClick={handleSend} disabled={msgSending || !msgText.trim()}>
            {msgSending ? "Enviando..." : "Enviar"}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Leads;

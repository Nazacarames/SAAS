import Contact from "../../models/Contact";
import Webhook from "../../models/Webhook";

const safeJson = async (res: any) => {
  try { return await res.json(); } catch { return null; }
};

const CheckInactiveContactsService = async () => {
  const now = Date.now();

  const contacts = await Contact.findAll({
    where: {
      inactivityWebhookId: { [require("sequelize").Op.ne]: null }
    } as any
  });

  for (const c of contacts) {
    const inactivityMinutes = Number((c as any).inactivityMinutes || 0);
    const webhookId = (c as any).inactivityWebhookId;
    if (!webhookId || !inactivityMinutes) continue;

    const last = (c as any).lastInteractionAt ? new Date((c as any).lastInteractionAt).getTime() : null;
    if (!last) continue;

    const dueMs = inactivityMinutes * 60_000;
    if (now - last < dueMs) continue;

    const lastFired = (c as any).lastInactivityFiredAt ? new Date((c as any).lastInactivityFiredAt).getTime() : 0;
    if (lastFired && lastFired >= last) continue; // already fired after last interaction

    const webhook = await Webhook.findByPk(webhookId);
    if (!webhook || !(webhook as any).active) continue;

    const payload = {
      event: "contact.inactive",
      contact: {
        id: c.id,
        name: (c as any).name,
        number: (c as any).number,
        email: (c as any).email,
        source: (c as any).source,
        leadStatus: (c as any).leadStatus,
        assignedUserId: (c as any).assignedUserId,
        lastInteractionAt: (c as any).lastInteractionAt,
        inactivityMinutes
      },
      timestamp: new Date().toISOString()
    };

    try {
      const res = await fetch((webhook as any).url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      await safeJson(res);
      await (c as any).update({ lastInactivityFiredAt: new Date() } as any);
      console.log(`[inactivity] fired webhook ${webhookId} for contact ${c.id}`);
    } catch (err: any) {
      console.error(`[inactivity] failed for contact ${c.id}:`, err?.message || err);
    }
  }
};

export default CheckInactiveContactsService;

import Ticket from "../../models/Ticket";

interface Request {
  companyId: number;
  ticketId: number;
  status?: "pending" | "open" | "closed";
  userId?: number | null;
  queueId?: number | null;
}

const UpdateTicketService = async ({ companyId, ticketId, status, userId, queueId }: Request) => {
  const ticket = await Ticket.findOne({ where: { id: ticketId, companyId } });
  if (!ticket) {
    const err: any = new Error("Ticket not found");
    err.statusCode = 404;
    throw err;
  }

  if (typeof status !== "undefined") ticket.status = status;
  if (typeof userId !== "undefined") ticket.userId = userId as any;
  if (typeof queueId !== "undefined") ticket.queueId = queueId as any;

  await ticket.save();
  return ticket;
};

export default UpdateTicketService;

import { Router } from "express";
import isAuth from "../middleware/isAuth";
import isAdmin from "../middleware/isAdmin";

const settingsRoutes = Router();

const maskKey = (key: string) => {
  if (!key) return "";
  if (key.length <= 8) return "*".repeat(key.length);
  return `${key.slice(0, 4)}${"*".repeat(Math.max(4, key.length - 8))}${key.slice(-4)}`;
};

// Integrations API key (used by /api/integrations/* with x-api-key)
settingsRoutes.get("/integrations/api-key", isAuth, isAdmin, async (req, res) => {
  const apiKey = process.env.INTEGRATIONS_API_KEY || "";

  return res.json({
    configured: Boolean(apiKey),
    apiKey,
    apiKeyMasked: apiKey ? maskKey(apiKey) : ""
  });
});

export default settingsRoutes;

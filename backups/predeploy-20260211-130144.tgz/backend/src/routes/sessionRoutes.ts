import { Router } from "express";
import isAuth from "../middleware/isAuth";
import StartWhatsAppSession from "../services/WbotServices/StartWhatsAppSession";

const sessionRoutes = Router();

sessionRoutes.post("/:whatsappId", isAuth, async (req, res) => {
    const { whatsappId } = req.params;

    await StartWhatsAppSession({ whatsappId: parseInt(whatsappId) });

    return res.json({ message: "Sesión iniciada" });
});

export default sessionRoutes;

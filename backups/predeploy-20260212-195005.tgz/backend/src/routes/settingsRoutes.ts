import { Router } from "express";
import isAuth from "../middleware/isAuth";
import isAdmin from "../middleware/isAdmin";
import { getRuntimeSettings, saveRuntimeSettings } from "../services/SettingsServices/RuntimeSettingsService";

const settingsRoutes = Router();
const maskKey = (key: string) => (!key ? "" : key.length <= 8 ? "*".repeat(key.length) : `${key.slice(0, 4)}${"*".repeat(Math.max(4, key.length - 8))}${key.slice(-4)}`);

settingsRoutes.get("/integrations/api-key", isAuth, isAdmin, async (_req, res) => {
  const apiKey = process.env.INTEGRATIONS_API_KEY || "";
  return res.json({ configured: Boolean(apiKey), apiKey, apiKeyMasked: apiKey ? maskKey(apiKey) : "" });
});

settingsRoutes.get("/whatsapp-cloud", isAuth, isAdmin, async (_req, res) => {
  const settings = getRuntimeSettings();
  return res.json({
    configured: {
      verifyToken: Boolean(settings.waCloudVerifyToken), phoneNumberId: Boolean(settings.waCloudPhoneNumberId), accessToken: Boolean(settings.waCloudAccessToken), appSecret: Boolean(settings.waCloudAppSecret), recapTemplate: Boolean(settings.waRecapTemplateName)
    },
    settings: { ...settings, waCloudAccessTokenMasked: settings.waCloudAccessToken ? maskKey(settings.waCloudAccessToken) : "", waCloudAppSecretMasked: settings.waCloudAppSecret ? maskKey(settings.waCloudAppSecret) : "" }
  });
});

settingsRoutes.put("/whatsapp-cloud", isAuth, isAdmin, async (req, res) => {
  const body = req.body || {};
  const next = saveRuntimeSettings({
    waCloudVerifyToken: String(body.waCloudVerifyToken ?? ""),
    waCloudPhoneNumberId: String(body.waCloudPhoneNumberId ?? ""),
    waCloudAccessToken: String(body.waCloudAccessToken ?? ""),
    waCloudAppSecret: String(body.waCloudAppSecret ?? ""),
    waCloudDefaultWhatsappId: Number(body.waCloudDefaultWhatsappId || 1),
    waRecapEnabled: typeof body.waRecapEnabled === "boolean" ? body.waRecapEnabled : false,
    waRecapTemplateName: String(body.waRecapTemplateName ?? ""),
    waRecapTemplateLang: String(body.waRecapTemplateLang ?? "es_AR"),
    waRecapInactivityMinutes: Number(body.waRecapInactivityMinutes || 4320),
    agentGuardrailsEnabled: typeof body.agentGuardrailsEnabled === "boolean" ? body.agentGuardrailsEnabled : true,
    agentConversationPoliciesJson: String(body.agentConversationPoliciesJson ?? "")
  });
  return res.json({ ok: true, settings: next });
});

export default settingsRoutes;
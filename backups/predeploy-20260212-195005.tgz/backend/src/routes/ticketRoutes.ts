import { Router } from "express";
import isAuth from "../middleware/isAuth";
import ListTicketsService from "../services/TicketServices/ListTicketsService";
import UpdateTicketService from "../services/TicketServices/UpdateTicketService";

const ticketRoutes = Router();

ticketRoutes.get("/", isAuth, async (req: any, res) => {
  const { companyId } = req.user;
  const { status, contactId } = req.query;

  const tickets = await ListTicketsService({ companyId, status, contactId: contactId ? parseInt(contactId) : undefined });
  return res.json(tickets);
});

ticketRoutes.put("/:ticketId", isAuth, async (req: any, res) => {
  const { companyId } = req.user;
  const { ticketId } = req.params;
  const { status, userId, queueId } = req.body;

  const ticket = await UpdateTicketService({
    companyId,
    ticketId: parseInt(ticketId),
    status,
    userId: typeof userId === "number" ? userId : userId === null ? null : undefined,
    queueId: typeof queueId === "number" ? queueId : queueId === null ? null : undefined
  });

  return res.json(ticket);
});

export default ticketRoutes;

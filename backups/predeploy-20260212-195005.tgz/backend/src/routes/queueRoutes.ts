import { Router } from "express";
import isAuth from "../middleware/isAuth";
import isAdmin from "../middleware/isAdmin";
import ListQueuesService from "../services/QueueServices/ListQueuesService";
import CreateQueueService from "../services/QueueServices/CreateQueueService";

const queueRoutes = Router();

queueRoutes.get("/", isAuth, isAdmin, async (req: any, res) => {
    const { companyId } = req.user;

    const queues = await ListQueuesService({ companyId });

    return res.json(queues);
});

queueRoutes.post("/", isAuth, isAdmin, async (req: any, res) => {
    const { companyId } = req.user;
    const { name, color, greetingMessage } = req.body;

    const queue = await CreateQueueService({
        name,
        color,
        greetingMessage,
        companyId
    });

    return res.status(201).json(queue);
});

export default queueRoutes;

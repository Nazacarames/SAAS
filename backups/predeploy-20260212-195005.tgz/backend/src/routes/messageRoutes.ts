import { Router } from "express";
import isAuth from "../middleware/isAuth";
import SendMessageService from "../services/MessageServices/SendMessageService";
import ListMessagesService from "../services/MessageServices/ListMessagesService";

const messageRoutes = Router();

// List messages for a ticket
messageRoutes.get("/:ticketId", isAuth, async (req: any, res) => {
  const { ticketId } = req.params;
  const messages = await ListMessagesService({ ticketId: parseInt(ticketId) });
  return res.json(messages);
});

// Send message to the ticket contact via WhatsApp
messageRoutes.post("/", isAuth, async (req: any, res) => {
  const { body, ticketId } = req.body;
  const { id: userId } = req.user;

  const message = await SendMessageService({
    body,
    ticketId,
    userId
  });

  return res.status(201).json(message);
});

export default messageRoutes;

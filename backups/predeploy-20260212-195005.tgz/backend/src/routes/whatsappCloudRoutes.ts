import { Router } from "express";
import { processCloudWebhookPayload } from "../services/WhatsAppCloudServices/ProcessCloudWebhookService";
import { getRuntimeSettings } from "../services/SettingsServices/RuntimeSettingsService";

const whatsappCloudRoutes = Router();

whatsappCloudRoutes.get("/webhook", (req: any, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  const expected = getRuntimeSettings().waCloudVerifyToken || "";

  if (mode === "subscribe" && expected && token === expected) {
    return res.status(200).send(String(challenge || ""));
  }

  return res.status(403).json({ error: "Verification failed" });
});

whatsappCloudRoutes.post("/webhook", async (req, res) => {
  const result = await processCloudWebhookPayload(req.body || {});
  return res.status(200).json({ ok: true, ...result });
});

export default whatsappCloudRoutes;

import Whatsapp from "../../models/Whatsapp";
import Contact from "../../models/Contact";
import Ticket from "../../models/Ticket";
import Message from "../../models/Message";
import crypto from "crypto";
import AppError from "../../errors/AppError";
import { getWbot } from "../../libs/wbot";
import { getIO } from "../../libs/socket";

interface SendOutboundTextRequest {
  companyId: number;
  whatsappId?: number;
  to: string;
  text: string;
  contactName?: string;
  queueId?: number;
}

const normalizeNumber = (raw: string): string => (raw || "").replace(/\D/g, "");

const SendOutboundTextService = async ({ companyId, whatsappId, to, text, contactName, queueId }: SendOutboundTextRequest) => {
  const toNorm = normalizeNumber(to);
  if (!toNorm) throw new AppError("Invalid destination number", 400);
  if (!text?.trim()) throw new AppError("Text is required", 400);

  const wa = whatsappId
    ? await Whatsapp.findOne({ where: { id: whatsappId, companyId } })
    : await Whatsapp.findOne({ where: { companyId, isDefault: true } });

  if (!wa) throw new AppError("No WhatsApp connection available", 400);

  const wbot = getWbot(wa.id);
  if (!wbot) throw new AppError("WhatsApp not connected", 400);

  let contact = await Contact.findOne({ where: { companyId, number: toNorm } });
  if (!contact) {
    contact = await Contact.create({
      companyId,
      name: contactName || toNorm,
      number: toNorm,
      email: "",
      profilePicUrl: "",
      isGroup: false,
      whatsappId: wa.id
    });
  }

  // Find or create a ticket
  let ticket = await Ticket.findOne({
    where: { companyId, contactId: contact.id, whatsappId: wa.id },
    order: [["updatedAt", "DESC"]]
  });

  if (!ticket) {
    ticket = await Ticket.create({
      companyId,
      contactId: contact.id,
      whatsappId: wa.id,
      queueId: queueId || null,
      status: "open",
      unreadMessages: 0,
      lastMessage: text,
      isGroup: false
    });
  }

  const jid = `${toNorm}@s.whatsapp.net`;
  const sent = await wbot.sendMessage(jid, { text });

  const msg = await Message.create({
    id: sent?.key?.id || crypto.randomUUID(),
    body: text,
    contactId: contact.id,
    ticketId: ticket.id,
    fromMe: true,
    read: true,
    mediaType: "chat"
  });

  await ticket.update({ lastMessage: text, updatedAt: new Date() });

  const io = getIO();
  io.to(`ticket-${ticket.id}`).emit("appMessage", { action: "create", message: msg, ticket, contact });

  return { ticket, contact, message: msg };
};

export default SendOutboundTextService;

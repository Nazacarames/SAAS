import { getWbot } from "../../libs/wbot";
import Message from "../../models/Message";
import Ticket from "../../models/Ticket";
import Contact from "../../models/Contact";
import AppError from "../../errors/AppError";
import { getIO } from "../../libs/socket";
import crypto from "crypto";

interface SendMessageRequest {
  body: string;
  ticketId: number;
  userId: number;
}

const SendMessageService = async ({ body, ticketId }: SendMessageRequest): Promise<Message> => {
  const ticket = await Ticket.findByPk(ticketId, {
    include: [
      { model: Contact, as: "contact" },
      { model: require("../../models/Whatsapp").default, as: "whatsapp" }
    ]
  });

  if (!ticket) {
    throw new AppError("Ticket no encontrado", 404);
  }

  const wbot = getWbot(ticket.whatsappId);
  if (!wbot) {
    throw new AppError("WhatsApp no conectado", 404);
  }

  const contactNumber = `${ticket.contact.number}@s.whatsapp.net`;

  try {
    const sentMessage: any = await wbot.sendMessage(contactNumber, { text: body });
    const msgId = sentMessage?.key?.id || crypto.randomUUID();

    const message = await Message.create({
      id: msgId,
      body,
      contactId: ticket.contactId,
      ticketId: ticket.id,
      fromMe: true,
      read: true,
      ack: 0,
      mediaType: "chat"
    } as any);

    await ticket.update({
      lastMessage: body,
      updatedAt: new Date()
    });

    const io = getIO();
    io.to(`ticket-${ticket.id}`).emit("appMessage", {
      action: "create",
      message,
      ticket,
      contact: ticket.contact
    });

    return message;
  } catch (error) {
    console.error("Error al enviar mensaje:", error);
    throw new AppError("Error al enviar mensaje", 500);
  }
};

export default SendMessageService;

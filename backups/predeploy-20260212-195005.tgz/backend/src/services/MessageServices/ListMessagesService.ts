import Message from "../../models/Message";
import Contact from "../../models/Contact";
import Ticket from "../../models/Ticket";

interface ListMessagesRequest {
    ticketId: number;
}

const ListMessagesService = async ({ ticketId }: ListMessagesRequest): Promise<Message[]> => {
    const messages = await Message.findAll({
        where: { ticketId },
        include: [
            {
                model: Contact,
                as: "contact",
                attributes: ["id", "name", "number", "profilePicUrl"]
            }
        ],
        order: [["createdAt", "ASC"]]
    });

    return messages;
};

export default ListMessagesService;

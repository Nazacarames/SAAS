import Queue from "../../models/Queue";
import AppError from "../../errors/AppError";

interface CreateQueueRequest {
    name: string;
    color: string;
    greetingMessage?: string;
    companyId: number;
}

const CreateQueueService = async (data: CreateQueueRequest): Promise<Queue> => {
    const { name, color, greetingMessage = "", companyId } = data;

    const queue = await Queue.create({
        name,
        color,
        greetingMessage,
        companyId
    });

    return queue;
};

export default CreateQueueService;

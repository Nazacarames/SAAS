import Queue from "../../models/Queue";

interface ListQueuesRequest {
    companyId: number;
}

const ListQueuesService = async ({ companyId }: ListQueuesRequest): Promise<Queue[]> => {
    const queues = await Queue.findAll({
        where: { companyId },
        order: [["name", "ASC"]]
    });

    return queues;
};

export default ListQueuesService;

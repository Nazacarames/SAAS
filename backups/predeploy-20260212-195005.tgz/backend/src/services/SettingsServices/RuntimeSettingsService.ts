import fs from "fs";
import path from "path";

export interface RuntimeSettings {
  waCloudVerifyToken: string;
  waCloudPhoneNumberId: string;
  waCloudAccessToken: string;
  waCloudAppSecret: string;
  waCloudDefaultWhatsappId: number;
  waRecapEnabled: boolean;
  waRecapTemplateName: string;
  waRecapTemplateLang: string;
  waRecapInactivityMinutes: number;
  agentGuardrailsEnabled: boolean;
  agentConversationPoliciesJson: string;
}

const FILE_PATH = path.resolve(process.cwd(), "runtime-settings.json");
const defaultPoliciesJson = JSON.stringify({
  sales: { maxReplyChars: 280, allowAutoClose: false, autoHandoffOnSensitive: false },
  support: { maxReplyChars: 320, allowAutoClose: false, autoHandoffOnSensitive: true },
  scheduling: { maxReplyChars: 220, allowAutoClose: true, autoHandoffOnSensitive: false },
  general: { maxReplyChars: 260, allowAutoClose: true, autoHandoffOnSensitive: false }
});

const readFileSettings = (): Partial<RuntimeSettings> => {
  try { if (!fs.existsSync(FILE_PATH)) return {}; return JSON.parse(fs.readFileSync(FILE_PATH, "utf-8") || "{}"); } catch { return {}; }
};
const writeFileSettings = (settings: Partial<RuntimeSettings>) => fs.writeFileSync(FILE_PATH, JSON.stringify(settings, null, 2), "utf-8");
const parseBool = (v: any, fallback = false) => (typeof v === "boolean" ? v : (typeof v === "string" ? ["1", "true", "yes", "on"].includes(v.trim().toLowerCase()) : fallback));

export const getRuntimeSettings = (): RuntimeSettings => {
  const fromFile = readFileSettings() as any;
  const recapEnabledFile = parseBool(fromFile.waRecapEnabled, false);
  const recapEnabledEnv = parseBool(process.env.WA_RECAP_ENABLED, false);
  return {
    waCloudVerifyToken: String(fromFile.waCloudVerifyToken || "") || process.env.WA_CLOUD_VERIFY_TOKEN || "",
    waCloudPhoneNumberId: String(fromFile.waCloudPhoneNumberId || "") || process.env.WA_CLOUD_PHONE_NUMBER_ID || "",
    waCloudAccessToken: String(fromFile.waCloudAccessToken || "") || process.env.WA_CLOUD_ACCESS_TOKEN || "",
    waCloudAppSecret: String(fromFile.waCloudAppSecret || "") || process.env.WA_CLOUD_APP_SECRET || "",
    waCloudDefaultWhatsappId: Number(fromFile.waCloudDefaultWhatsappId || process.env.WA_CLOUD_DEFAULT_WHATSAPP_ID || 1),
    waRecapEnabled: recapEnabledFile || recapEnabledEnv,
    waRecapTemplateName: String(fromFile.waRecapTemplateName || "") || process.env.WA_RECAP_TEMPLATE_NAME || "",
    waRecapTemplateLang: String(fromFile.waRecapTemplateLang || "") || process.env.WA_RECAP_TEMPLATE_LANG || "es_AR",
    waRecapInactivityMinutes: Number(fromFile.waRecapInactivityMinutes || process.env.WA_RECAP_INACTIVITY_MINUTES || 4320),
    agentGuardrailsEnabled: parseBool(fromFile.agentGuardrailsEnabled, true),
    agentConversationPoliciesJson: String(fromFile.agentConversationPoliciesJson || "") || defaultPoliciesJson
  };
};

export const saveRuntimeSettings = (patch: Partial<RuntimeSettings>) => {
  const current = getRuntimeSettings();
  const next: RuntimeSettings = {
    ...current,
    ...patch,
    waCloudDefaultWhatsappId: Number(patch.waCloudDefaultWhatsappId || current.waCloudDefaultWhatsappId || 1),
    waRecapEnabled: typeof patch.waRecapEnabled === "boolean" ? patch.waRecapEnabled : current.waRecapEnabled,
    waRecapTemplateName: String(patch.waRecapTemplateName ?? current.waRecapTemplateName ?? ""),
    waRecapTemplateLang: String(patch.waRecapTemplateLang ?? current.waRecapTemplateLang ?? "es_AR"),
    waRecapInactivityMinutes: Number(patch.waRecapInactivityMinutes || current.waRecapInactivityMinutes || 4320),
    agentGuardrailsEnabled: typeof patch.agentGuardrailsEnabled === "boolean" ? patch.agentGuardrailsEnabled : current.agentGuardrailsEnabled,
    agentConversationPoliciesJson: String(patch.agentConversationPoliciesJson ?? current.agentConversationPoliciesJson ?? defaultPoliciesJson)
  };
  writeFileSettings(next);
  return next;
};
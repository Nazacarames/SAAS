import Whatsapp from "../../models/Whatsapp";

interface ListWhatsappsRequest {
    companyId: number;
}

const ListWhatsappsService = async ({ companyId }: ListWhatsappsRequest): Promise<Whatsapp[]> => {
    const whatsapps = await Whatsapp.findAll({
        where: { companyId },
        attributes: ["id", "name", "status", "qrcode", "battery", "plugged", "isDefault"],
        order: [["name", "ASC"]]
    });

    return whatsapps;
};

export default ListWhatsappsService;

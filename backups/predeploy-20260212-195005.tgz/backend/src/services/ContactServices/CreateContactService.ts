import Contact from "../../models/Contact";
import Tag from "../../models/Tag";
import UpsertTagsService from "../TagServices/UpsertTagsService";

interface Request {
  companyId: number;
  name: string;
  number: string;
  email?: string;
  whatsappId?: number | null;
  source?: string;
  leadStatus?: string;
  assignedUserId?: number | null;
  inactivityMinutes?: number;
  inactivityWebhookId?: number | null;
  tags?: string[];
}

const CreateContactService = async ({
  companyId,
  name,
  number,
  email,
  whatsappId,
  source,
  leadStatus,
  assignedUserId,
  inactivityMinutes,
  inactivityWebhookId,
  tags
}: Request) => {
  const contact = await Contact.create({
    companyId,
    name,
    number: number.replace(/\D/g, ""),
    email: email || "",
    whatsappId: whatsappId || null,
    source: source || null,
    leadStatus: leadStatus || "unread",
    assignedUserId: assignedUserId || null,
    inactivityMinutes: typeof inactivityMinutes === "number" ? inactivityMinutes : 30,
    inactivityWebhookId: inactivityWebhookId || null,
    lastInteractionAt: new Date()
  } as any);

  if (tags?.length) {
    const tagModels = await UpsertTagsService(tags);
    await (contact as any).$set("tags", tagModels);
  }

  const reloaded = await Contact.findByPk(contact.id, { include: [{ model: Tag, as: "tags" }] });
  return reloaded || contact;
};

export default CreateContactService;

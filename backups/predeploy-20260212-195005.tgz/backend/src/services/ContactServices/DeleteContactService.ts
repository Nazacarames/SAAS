import Contact from "../../models/Contact";

interface Request {
  companyId: number;
  contactId: number;
}

const DeleteContactService = async ({ companyId, contactId }: Request) => {
  const contact = await Contact.findOne({ where: { id: contactId, companyId } });
  if (!contact) {
    const err: any = new Error("Contact not found");
    err.statusCode = 404;
    throw err;
  }

  await contact.destroy();
};

export default DeleteContactService;

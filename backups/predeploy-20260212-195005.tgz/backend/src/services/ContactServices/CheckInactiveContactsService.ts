import crypto from "crypto";
import { Op } from "sequelize";

import Contact from "../../models/Contact";
import Webhook from "../../models/Webhook";
import Ticket from "../../models/Ticket";
import Whatsapp from "../../models/Whatsapp";
import Message from "../../models/Message";
import { getRuntimeSettings } from "../SettingsServices/RuntimeSettingsService";
import { getIO } from "../../libs/socket";

const safeJson = async (res: any) => {
  try {
    return await res.json();
  } catch {
    return null;
  }
};

const sendMetaTemplate = async (to: string, templateName: string, lang: string, phoneNumberId: string, accessToken: string) => {
  const payload = {
    messaging_product: "whatsapp",
    to,
    type: "template",
    template: {
      name: templateName,
      language: { code: lang || "es_AR" }
    }
  };

  const res = await fetch(`https://graph.facebook.com/v21.0/${phoneNumberId}/messages`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`
    },
    body: JSON.stringify(payload)
  });

  const data = await safeJson(res);
  if (!res.ok) {
    throw new Error(data?.error?.message || `Meta template send failed (${res.status})`);
  }

  const messageId = data?.messages?.[0]?.id || crypto.randomUUID();
  return { messageId, raw: data };
};

const findOrCreateTicket = async (contact: Contact, whatsappId: number, companyId: number) => {
  let ticket = await Ticket.findOne({
    where: {
      contactId: contact.id,
      whatsappId,
      status: { [Op.ne]: "closed" }
    },
    order: [["updatedAt", "DESC"]]
  });

  if (!ticket) {
    ticket = await Ticket.create({
      companyId,
      contactId: contact.id,
      whatsappId,
      status: "open",
      unreadMessages: 0,
      lastMessage: "",
      isGroup: false
    } as any);
  }

  return ticket;
};

const CheckInactiveContactsService = async () => {
  const now = Date.now();
  const runtime = getRuntimeSettings();

  const contacts = await Contact.findAll({
    where: {
      number: { [Op.ne]: null }
    } as any
  });

  let defaultWa: any = null;
  if (runtime.waCloudDefaultWhatsappId) {
    defaultWa = await Whatsapp.findByPk(runtime.waCloudDefaultWhatsappId);
  }
  if (!defaultWa) defaultWa = await Whatsapp.findOne({ where: { isDefault: true } });
  if (!defaultWa) defaultWa = await Whatsapp.findOne();

  for (const c of contacts) {
    const number = String((c as any).number || "").replace(/\D/g, "");
    if (!number) continue;

    const inactivityMinutesContact = Number((c as any).inactivityMinutes || 0);
    const inactivityMinutes = inactivityMinutesContact > 0 ? inactivityMinutesContact : Number(runtime.waRecapInactivityMinutes || 4320);

    const last = (c as any).lastInteractionAt
      ? new Date((c as any).lastInteractionAt).getTime()
      : new Date((c as any).updatedAt || (c as any).createdAt || Date.now()).getTime();

    if (!last || !inactivityMinutes) continue;

    const dueMs = inactivityMinutes * 60_000;
    if (now - last < dueMs) continue;

    const lastFired = (c as any).lastInactivityFiredAt
      ? new Date((c as any).lastInactivityFiredAt).getTime()
      : 0;

    if (lastFired && lastFired >= last) continue;

    // 1) Automatic WhatsApp Cloud recapture template
    if (
      runtime.waRecapEnabled &&
      runtime.waRecapTemplateName &&
      runtime.waCloudPhoneNumberId &&
      runtime.waCloudAccessToken
    ) {
      try {
        const { messageId } = await sendMetaTemplate(
          number,
          runtime.waRecapTemplateName,
          runtime.waRecapTemplateLang || "es_AR",
          runtime.waCloudPhoneNumberId,
          runtime.waCloudAccessToken
        );

        if (defaultWa) {
          const ticket = await findOrCreateTicket(c, defaultWa.id, (c as any).companyId);
          const body = `[TEMPLATE:${runtime.waRecapTemplateName}] Recaptación automática por inactividad (${Math.round(inactivityMinutes / 1440)} día/s)`;

          const msg = await Message.create({
            id: messageId,
            body,
            contactId: c.id,
            ticketId: ticket.id,
            fromMe: true,
            read: true,
            ack: 1,
            mediaType: "chat"
          } as any);

          await ticket.update({ lastMessage: body, updatedAt: new Date() } as any);

          try {
            const io = getIO();
            io.to(`ticket-${ticket.id}`).emit("appMessage", {
              action: "create",
              message: msg,
              ticket,
              contact: c
            });
          } catch {}
        }

        await (c as any).update({ lastInactivityFiredAt: new Date() } as any);
        console.log(`[inactivity] template recapture sent contact=${c.id} number=${number}`);
      } catch (err: any) {
        console.error(`[inactivity] template recapture failed contact=${c.id}:`, err?.message || err);
      }
    }

    // 2) Legacy inactivity webhook (if configured per contact)
    const webhookId = (c as any).inactivityWebhookId;
    if (webhookId) {
      const webhook = await Webhook.findByPk(webhookId);
      if (webhook && (webhook as any).active) {
        const payload = {
          event: "contact.inactive",
          contact: {
            id: c.id,
            name: (c as any).name,
            number: (c as any).number,
            email: (c as any).email,
            source: (c as any).source,
            leadStatus: (c as any).leadStatus,
            assignedUserId: (c as any).assignedUserId,
            lastInteractionAt: (c as any).lastInteractionAt,
            inactivityMinutes
          },
          timestamp: new Date().toISOString()
        };

        try {
          const res = await fetch((webhook as any).url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
          });
          await safeJson(res);
          await (c as any).update({ lastInactivityFiredAt: new Date() } as any);
          console.log(`[inactivity] fired webhook ${webhookId} for contact ${c.id}`);
        } catch (err: any) {
          console.error(`[inactivity] webhook failed for contact ${c.id}:`, err?.message || err);
        }
      }
    }
  }
};

export default CheckInactiveContactsService;

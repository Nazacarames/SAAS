import crypto from "crypto";
import { Op, QueryTypes } from "sequelize";

import Contact from "../../models/Contact";
import Ticket from "../../models/Ticket";
import Message from "../../models/Message";
import Whatsapp from "../../models/Whatsapp";
import Tag from "../../models/Tag";
import ContactTag from "../../models/ContactTag";
import sequelize from "../../database";
import { getIO } from "../../libs/socket";
import { recordInboundDuplicate, recordInboundError, recordInboundMessage } from "../../utils/messageStats";
import { getRuntimeSettings } from "../SettingsServices/RuntimeSettingsService";

type MetaWebhookPayload = { entry?: Array<{ changes?: Array<{ value?: { messages?: Array<{ id?: string; from?: string; timestamp?: string; type?: string; text?: { body?: string } }> } }> }> };
type ConversationType = "sales" | "support" | "scheduling" | "general";
type Policy = { maxReplyChars?: number; allowAutoClose?: boolean; autoHandoffOnSensitive?: boolean; forbiddenKeywords?: string[] };

const defaultPolicies: Record<ConversationType, Policy> = {
  sales: { maxReplyChars: 280, allowAutoClose: false, autoHandoffOnSensitive: false, forbiddenKeywords: ["descuento extremo", "garantía absoluta"] },
  support: { maxReplyChars: 320, allowAutoClose: false, autoHandoffOnSensitive: true, forbiddenKeywords: ["culpa del cliente"] },
  scheduling: { maxReplyChars: 220, allowAutoClose: true, autoHandoffOnSensitive: false, forbiddenKeywords: [] },
  general: { maxReplyChars: 260, allowAutoClose: true, autoHandoffOnSensitive: false, forbiddenKeywords: [] }
};

let decisionTableReady = false;
const ensureDecisionTable = async () => {
  if (decisionTableReady) return;
  await sequelize.query(`CREATE TABLE IF NOT EXISTS ai_decision_logs (id SERIAL PRIMARY KEY, company_id INTEGER NOT NULL, ticket_id INTEGER NOT NULL, conversation_type VARCHAR(32) NOT NULL, decision_key VARCHAR(80) NOT NULL, reason TEXT, guardrail_action VARCHAR(80), response_preview TEXT, created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW())`);
  decisionTableReady = true;
};
const logDecision = async (args: { companyId: number; ticketId: number; conversationType: ConversationType; decisionKey: string; reason?: string; guardrailAction?: string; responsePreview?: string }) => {
  await ensureDecisionTable();
  await sequelize.query(`INSERT INTO ai_decision_logs (company_id, ticket_id, conversation_type, decision_key, reason, guardrail_action, response_preview, created_at) VALUES (:companyId, :ticketId, :conversationType, :decisionKey, :reason, :guardrailAction, :responsePreview, NOW())`, { replacements: args, type: QueryTypes.INSERT });
};
const resolvePolicies = (): Record<ConversationType, Policy> => {
  const rt = getRuntimeSettings();
  if (!rt.agentGuardrailsEnabled) return defaultPolicies;
  try {
    const parsed = JSON.parse(rt.agentConversationPoliciesJson || "{}");
    return { sales: { ...defaultPolicies.sales, ...(parsed.sales || {}) }, support: { ...defaultPolicies.support, ...(parsed.support || {}) }, scheduling: { ...defaultPolicies.scheduling, ...(parsed.scheduling || {}) }, general: { ...defaultPolicies.general, ...(parsed.general || {}) } };
  } catch { return defaultPolicies; }
};
const classifyConversation = (text: string): ConversationType => {
  const t = String(text || "").toLowerCase();
  if (/turno|agenda|cita|horario|fecha|mañana|lunes|martes/.test(t)) return "scheduling";
  if (/error|soporte|no funciona|problema|incidente|ca[ií]do/.test(t)) return "support";
  if (/precio|plan|comprar|contratar|promo|descuento|cotiz/.test(t)) return "sales";
  return "general";
};
const applyGuardrails = async ({ text, reply, conversationType }: { text: string; reply: string; conversationType: ConversationType }): Promise<{ finalReply?: string; handoff?: boolean; reason: string; action: string }> => {
  const policy = resolvePolicies()[conversationType] || defaultPolicies.general;
  const low = text.toLowerCase();
  if (policy.autoHandoffOnSensitive && /legal|abogado|demanda|tarjeta|transferencia|cbu/.test(low)) return { handoff: true, reason: "Tema sensible detectado para soporte", action: "handoff_sensitive" };
  const forbidden = (policy.forbiddenKeywords || []).find((k) => k && reply.toLowerCase().includes(k.toLowerCase()));
  let safeReply = forbidden ? "Gracias por tu consulta. Te derivo con un asesor humano para darte una respuesta precisa." : reply;
  if (conversationType === "scheduling" && !/\d{1,2}[:.]\d{2}|mañana|tarde|noche|lunes|martes|miércoles|jueves|viernes|sábado|domingo/.test(low)) safeReply = "Perfecto, lo coordinamos. Indicame por favor día y franja horaria (ej: martes 15:30).";
  const max = Number(policy.maxReplyChars || 260);
  if (safeReply.length > max) safeReply = `${safeReply.slice(0, Math.max(60, max - 1))}…`;
  return { finalReply: safeReply, reason: forbidden ? `Keyword bloqueada: ${forbidden}` : "Guardrails aplicados", action: forbidden ? "rewrite_forbidden" : "allow" };
};

const resolveWhatsapp = async () => {
  const runtime = getRuntimeSettings();
  const preferredId = Number(runtime.waCloudDefaultWhatsappId || 0);
  if (preferredId > 0) { const byId = await Whatsapp.findByPk(preferredId); if (byId) return byId; }
  const byDefault = await Whatsapp.findOne({ where: { isDefault: true } }); if (byDefault) return byDefault;
  const anyWhatsapp = await Whatsapp.findOne(); if (anyWhatsapp) return anyWhatsapp;
  return Whatsapp.create({ name: "WhatsApp Cloud", status: "CONNECTED", isDefault: true, companyId: 1 } as any);
};
const getOrCreateContact = async (phone: string, companyId: number) => {
  let contact = await Contact.findOne({ where: { number: phone, companyId } });
  if (!contact) contact = await Contact.create({ name: phone, number: phone, companyId, isGroup: false });
  return contact;
};
const getOrCreateTicket = async (contactId: number, whatsappId: number, companyId: number) => {
  let ticket = await Ticket.findOne({ where: { contactId, whatsappId, status: { [Op.ne]: "closed" } }, order: [["updatedAt", "DESC"]] });
  if (!ticket) ticket = await Ticket.create({ contactId, whatsappId, companyId, status: "pending", unreadMessages: 1, lastMessage: "" } as any);
  return ticket;
};
const sendCloudText = async (to: string, text: string) => {
  const settings = getRuntimeSettings();
  if (!settings.waCloudPhoneNumberId || !settings.waCloudAccessToken) throw new Error("Cloud API credentials missing");
  const res = await fetch(`https://graph.facebook.com/v21.0/${settings.waCloudPhoneNumberId}/messages`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${settings.waCloudAccessToken}` }, body: JSON.stringify({ messaging_product: "whatsapp", to, type: "text", text: { body: text } }) });
  const data: any = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error?.message || `Cloud send failed (${res.status})`);
  return data?.messages?.[0]?.id || crypto.randomUUID();
};
const emitOutgoing = (ticket: any, contact: any, message: any) => { try { const io = getIO(); io.to(`ticket-${ticket.id}`).emit("appMessage", { action: "create", message, ticket, contact }); } catch {} };
const ensureArchivedTag = async (contactId: number) => { const [tag] = await Tag.findOrCreate({ where: { name: "archivado" }, defaults: { name: "archivado", color: "#6b7280" } }); const exists = await ContactTag.findOne({ where: { contactId, tagId: tag.id } }); if (!exists) await ContactTag.create({ contactId, tagId: tag.id } as any); };
const autoSummaryAndScore = async (ticketId: number, contact: Contact) => {
  const inbound = await Message.findAll({ where: { ticketId, fromMe: false }, order: [["createdAt", "DESC"]], limit: 6 });
  const joined = inbound.map((m: any) => String(m.body || "").trim()).filter(Boolean).reverse().join(" | ");
  if (!joined) return;
  let score = Number((contact as any).lead_score || 0);
  if (/comprar|contratar|precio|plan|quiero/i.test(joined)) score = Math.max(score, 65);
  if (/urgente|ahora|hoy/i.test(joined)) score = Math.max(score, 75);
  if (/gracias|resuelto|listo/i.test(joined)) score = Math.max(score, 40);
  await (contact as any).update({ needs: joined.slice(0, 900), lead_score: Math.min(100, score), updatedAt: new Date() } as any);
};
const aiReplyFor = async (text: string, companyId: number): Promise<string> => {
  const t = String(text || "").toLowerCase();
  if (/hola|buenas|buen día|buen dia/.test(t)) return "¡Hola! 👋 Soy el asistente de Charlott. Contame qué necesitás y te ayudo ahora mismo.";
  if (/precio|plan|costo|cu[aá]nto/.test(t)) return "Perfecto. Te cuento planes y precios según tu necesidad. Si querés, te hago una recomendación rápida en 2 pasos.";
  if (/turno|agenda|cita|horario/.test(t)) return "Genial, te ayudo a agendar. Decime día y franja horaria preferida y lo coordinamos.";
  if (/soporte|error|no funciona|problema/.test(t)) return "Gracias por avisar. Ya te ayudo con soporte. Si querés, pasame captura o detalle del error para resolverlo más rápido.";
  const rows: any[] = await sequelize.query(`SELECT c.chunk_text, d.title FROM kb_chunks c JOIN kb_documents d ON d.id = c.document_id WHERE d.company_id = :companyId AND LOWER(c.chunk_text) LIKE LOWER(:q) ORDER BY c.id DESC LIMIT 1`, { replacements: { companyId, q: `%${String(text || "").trim()}%` }, type: QueryTypes.SELECT });
  if (rows[0]?.chunk_text) return `Te respondo con info de ${rows[0].title || "nuestra base"}: ${String(rows[0].chunk_text).slice(0, 500)}`;
  return "Entendido 👍 ¿Querés que te ayude con precios, agenda de cita, o soporte?";
};

const runAutonomousAgent = async ({ ticket, contact, incomingText }: { ticket: any; contact: any; incomingText: string }) => {
  const text = String(incomingText || "").trim();
  if (!text || (ticket as any).human_override || (ticket as any).bot_enabled === false) return;
  const low = text.toLowerCase();
  const conversationType = classifyConversation(text);
  await sequelize.query(`INSERT INTO ai_turns (conversation_id, role, content, model, latency_ms, tokens_in, tokens_out, created_at, updated_at) VALUES (NULL, 'user', :content, 'wa-cloud', 0, 0, 0, NOW(), NOW())`, { replacements: { content: text }, type: QueryTypes.INSERT });

  if (/humano|asesor|agente|persona/.test(low)) {
    await ticket.update({ human_override: true, bot_enabled: false, updatedAt: new Date() } as any);
    const transferText = "Perfecto. Te paso con un asesor humano para continuar 🙌";
    await logDecision({ companyId: ticket.companyId, ticketId: ticket.id, conversationType, decisionKey: "manual_handoff", reason: "Cliente pidió humano", guardrailAction: "handoff", responsePreview: transferText });
    const msgId = await sendCloudText(String(contact.number), transferText);
    const out = await Message.create({ id: msgId, body: transferText, contactId: contact.id, ticketId: ticket.id, fromMe: true, read: true, ack: 1, mediaType: "chat" } as any);
    await ticket.update({ lastMessage: transferText, updatedAt: new Date() } as any);
    emitOutgoing(ticket, contact, out);
    return;
  }

  if (/gracias|perfecto|listo|resuelto/.test(low) && resolvePolicies()[conversationType]?.allowAutoClose) {
    const closeText = "¡Excelente! Cierro esta conversación por ahora ✅ Si necesitás algo más, escribime y la retomamos enseguida.";
    await logDecision({ companyId: ticket.companyId, ticketId: ticket.id, conversationType, decisionKey: "auto_close", reason: "Cierre positivo detectado", guardrailAction: "close", responsePreview: closeText });
    const msgId = await sendCloudText(String(contact.number), closeText);
    const out = await Message.create({ id: msgId, body: closeText, contactId: contact.id, ticketId: ticket.id, fromMe: true, read: true, ack: 1, mediaType: "chat" } as any);
    await ticket.update({ status: "closed", unreadMessages: 0, lastMessage: closeText, updatedAt: new Date() } as any);
    await ensureArchivedTag(contact.id); await (contact as any).update({ leadStatus: "read", lastInteractionAt: new Date() } as any); emitOutgoing(ticket, contact, out);
    return;
  }

  const baseReply = await aiReplyFor(text, ticket.companyId);
  const guardrail = await applyGuardrails({ text, reply: baseReply, conversationType });
  if (guardrail.handoff) {
    await ticket.update({ human_override: true, bot_enabled: false, updatedAt: new Date() } as any);
    const txt = "Gracias por tu mensaje. Te paso con un asesor humano para tratar este tema con prioridad.";
    await logDecision({ companyId: ticket.companyId, ticketId: ticket.id, conversationType, decisionKey: "guardrail_handoff", reason: guardrail.reason, guardrailAction: guardrail.action, responsePreview: txt });
    const msgId = await sendCloudText(String(contact.number), txt);
    const out = await Message.create({ id: msgId, body: txt, contactId: contact.id, ticketId: ticket.id, fromMe: true, read: true, ack: 1, mediaType: "chat" } as any);
    await ticket.update({ lastMessage: txt, updatedAt: new Date() } as any); emitOutgoing(ticket, contact, out); return;
  }

  const reply = guardrail.finalReply || baseReply;
  await logDecision({ companyId: ticket.companyId, ticketId: ticket.id, conversationType, decisionKey: "reply", reason: guardrail.reason, guardrailAction: guardrail.action, responsePreview: reply.slice(0, 240) });
  const outId = await sendCloudText(String(contact.number), reply);
  const out = await Message.create({ id: outId, body: reply, contactId: contact.id, ticketId: ticket.id, fromMe: true, read: true, ack: 1, mediaType: "chat" } as any);
  await ticket.update({ status: ticket.status === "pending" ? "open" : ticket.status, lastMessage: reply, updatedAt: new Date() } as any);
  emitOutgoing(ticket, contact, out); await autoSummaryAndScore(ticket.id, contact);
};

export const processCloudWebhookPayload = async (payload: MetaWebhookPayload) => {
  const whatsapp = await resolveWhatsapp();
  if (!whatsapp) return { processed: 0, ignored: 0, reason: "no_whatsapp_connection" };
  let processed = 0; let ignored = 0;
  for (const entry of payload.entry || []) for (const change of entry.changes || []) for (const incoming of change.value?.messages || []) {
    const from = String(incoming.from || "").replace(/\D/g, ""); const body = incoming.text?.body || ""; const externalMsgId = incoming.id || ""; const timestamp = Number(incoming.timestamp || 0);
    if (!from || !externalMsgId) { ignored += 1; continue; }
    try {
      const exists = await Message.findByPk(externalMsgId); if (exists) { recordInboundDuplicate(); ignored += 1; continue; }
      const contact = await getOrCreateContact(from, whatsapp.companyId); const ticket = await getOrCreateTicket(contact.id, whatsapp.id, whatsapp.companyId); const createdAt = timestamp ? new Date(timestamp * 1000) : new Date();
      const message = await Message.create({ id: externalMsgId || crypto.randomUUID(), body, contactId: contact.id, ticketId: ticket.id, fromMe: false, read: false, ack: 0, mediaType: incoming.type || "chat", createdAt, updatedAt: createdAt } as any);
      await ticket.update({ lastMessage: body, unreadMessages: (ticket.unreadMessages || 0) + 1, updatedAt: new Date() } as any);
      try { await (contact as any).update({ leadStatus: "unread", lastInteractionAt: new Date() } as any); } catch {}
      recordInboundMessage({ fromMe: false, createdAt });
      const io = getIO(); io.to(`ticket-${ticket.id}`).emit("appMessage", { action: "create", message, ticket, contact }); io.to("notification").emit("notification", { type: "new-message", ticketId: ticket.id, contactName: contact.name });
      try { await runAutonomousAgent({ ticket, contact, incomingText: body }); } catch (agentErr: any) { console.error("[wa-cloud][agent] error:", agentErr?.message || agentErr); }
      processed += 1;
    } catch (error) { recordInboundError(error); console.error("[wa-cloud] error processing inbound:", error); ignored += 1; }
  }
  return { processed, ignored };
};

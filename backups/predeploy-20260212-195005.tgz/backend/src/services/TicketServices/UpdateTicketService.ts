import Ticket from "../../models/Ticket";
import Contact from "../../models/Contact";
import Tag from "../../models/Tag";
import ContactTag from "../../models/ContactTag";

interface Request {
  companyId: number;
  ticketId: number;
  status?: "pending" | "open" | "closed";
  userId?: number | null;
  queueId?: number | null;
}

const ensureArchivedTag = async (contactId: number) => {
  const [tag] = await Tag.findOrCreate({
    where: { name: "archivado" },
    defaults: { name: "archivado", color: "#6b7280" }
  });

  const exists = await ContactTag.findOne({ where: { contactId, tagId: tag.id } });
  if (!exists) {
    await ContactTag.create({ contactId, tagId: tag.id } as any);
  }
};

const removeArchivedTag = async (contactId: number) => {
  const tag = await Tag.findOne({ where: { name: "archivado" } });
  if (!tag) return;
  await ContactTag.destroy({ where: { contactId, tagId: tag.id } });
};

const UpdateTicketService = async ({ companyId, ticketId, status, userId, queueId }: Request) => {
  const ticket = await Ticket.findOne({ where: { id: ticketId, companyId } });
  if (!ticket) {
    const err: any = new Error("Ticket not found");
    err.statusCode = 404;
    throw err;
  }

  const previousStatus = ticket.status;

  if (typeof status !== "undefined") ticket.status = status;
  if (typeof userId !== "undefined") ticket.userId = userId as any;
  if (typeof queueId !== "undefined") ticket.queueId = queueId as any;

  // Auto-archive behavior when a client is closed
  if (status === "closed") {
    ticket.unreadMessages = 0;

    try {
      const contact = await Contact.findOne({ where: { id: ticket.contactId, companyId } });
      if (contact) {
        await contact.update({ leadStatus: "read", lastInteractionAt: new Date() } as any);
        await ensureArchivedTag(contact.id);
      }
    } catch (e: any) {
      console.error("[ticket-close] archive mark failed:", e?.message || e);
    }
  }

  // If reopened, remove archived tag automatically
  if (previousStatus === "closed" && status && status !== "closed") {
    try {
      await removeArchivedTag(ticket.contactId);
    } catch (e: any) {
      console.error("[ticket-reopen] remove archive tag failed:", e?.message || e);
    }
  }

  await ticket.save();
  return ticket;
};

export default UpdateTicketService;

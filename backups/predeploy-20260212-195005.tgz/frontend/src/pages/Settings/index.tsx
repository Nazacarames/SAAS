import { useEffect, useMemo, useState } from 'react';
import {
  Typography,
  Box,
  Paper,
  Divider,
  Tabs,
  Tab,
  Stack,
  Chip,
  Button,
  TextField
} from '@mui/material';
import api from '../../services/api';

const mask = (v: string) => {
  if (!v) return '';
  if (v.length <= 6) return '*'.repeat(v.length);
  return `${v.slice(0, 3)}***${v.slice(-3)}`;
};

const CodeBlock = ({ text }: { text: string }) => (
  <Box
    component="pre"
    sx={{
      m: 0,
      p: 1.5,
      bgcolor: '#0b1220',
      color: '#e5e7eb',
      borderRadius: 1,
      overflowX: 'auto',
      fontSize: 12,
      lineHeight: 1.4
    }}
  >
    {text}
  </Box>
);

const Settings = () => {
  const [tab, setTab] = useState(0);
  const [health, setHealth] = useState<any>(null);
  const [loadingHealth, setLoadingHealth] = useState(false);

  const apiBase = (import.meta as any).env?.VITE_BACKEND_URL || '';
  const hostBase = useMemo(() => {
    // expected: https://login.charlott.ai/api
    return apiBase ? apiBase.replace(/\/?api\/?$/, '') : '';
  }, [apiBase]);

  const [integrationKey, setIntegrationKey] = useState('');
  const [showKey, setShowKey] = useState(false);

  const [waCloudVerifyToken, setWaCloudVerifyToken] = useState('');
  const [waCloudPhoneNumberId, setWaCloudPhoneNumberId] = useState('');
  const [waCloudAccessToken, setWaCloudAccessToken] = useState('');
  const [waCloudAppSecret, setWaCloudAppSecret] = useState('');
  const [waCloudDefaultWhatsappId, setWaCloudDefaultWhatsappId] = useState('1');
  const [savingWaCloud, setSavingWaCloud] = useState(false);
  const [showWaSecrets, setShowWaSecrets] = useState(false);

  const endpoints = useMemo(
    () => [
      {
        group: 'Salud / Estado',
        items: [
          {
            method: 'GET',
            path: '/health',
            auth: 'public',
            desc: 'Healthcheck del backend (OK si status=ok).'
          },
          {
            method: 'GET',
            path: '/api/health',
            auth: 'public',
            desc: 'Healthcheck expuesto por Nginx (mapea a /health).'
          }
        ]
      },
      {
        group: 'Autenticación',
        items: [
          {
            method: 'POST',
            path: '/api/auth/login',
            auth: 'public',
            desc: 'Login (email/password) → token + refreshToken.'
          },
          {
            method: 'POST',
            path: '/api/auth/refresh',
            auth: 'public',
            desc: 'Renueva token usando refreshToken.'
          }
        ]
      },
      {
        group: 'CRM (requiere JWT)',
        items: [
          { method: 'GET', path: '/api/users', auth: 'jwt', desc: 'Listar usuarios.' },
          { method: 'POST', path: '/api/users', auth: 'jwt', desc: 'Crear usuario.' },
          { method: 'GET', path: '/api/queues', auth: 'jwt', desc: 'Listar colas/departamentos.' },
          { method: 'POST', path: '/api/queues', auth: 'jwt', desc: 'Crear cola/departamento.' },
          { method: 'GET', path: '/api/contacts', auth: 'jwt', desc: 'Listar leads.' },
          { method: 'POST', path: '/api/contacts', auth: 'jwt', desc: 'Crear lead.' },
          { method: 'PUT', path: '/api/contacts/:contactId', auth: 'jwt', desc: 'Editar lead.' },
          { method: 'DELETE', path: '/api/contacts/:contactId', auth: 'jwt', desc: 'Eliminar lead.' },
          { method: 'POST', path: '/api/contacts/:contactId/message', auth: 'jwt', desc: 'Enviar mensaje a un lead (crea ticket si no existe).' },
          { method: 'GET', path: '/api/tickets', auth: 'jwt', desc: 'Listar tickets (query opcional: status).' },
          { method: 'PUT', path: '/api/tickets/:ticketId', auth: 'jwt', desc: 'Actualizar ticket: status/user/queue.' },
          { method: 'GET', path: '/api/messages/:ticketId', auth: 'jwt', desc: 'Listar mensajes por ticket.' },
          { method: 'POST', path: '/api/messages', auth: 'jwt', desc: 'Enviar mensaje en un ticket (WhatsApp).'
          },
          { method: 'GET', path: '/api/webhooks', auth: 'jwt', desc: 'Listar webhooks.' },
          { method: 'POST', path: '/api/webhooks', auth: 'jwt', desc: 'Crear webhook.' },
          { method: 'PUT', path: '/api/webhooks/:webhookId', auth: 'jwt', desc: 'Editar webhook.' },
          { method: 'DELETE', path: '/api/webhooks/:webhookId', auth: 'jwt', desc: 'Eliminar webhook.' },
          { method: 'GET', path: '/api/whatsapps', auth: 'jwt', desc: 'Listar conexiones WhatsApp.' },
          { method: 'GET', path: '/api/whatsapps/:whatsappId', auth: 'jwt', desc: 'Detalle de conexión WhatsApp.' },
          { method: 'POST', path: '/api/sessions/:whatsappId', auth: 'jwt', desc: 'Iniciar sesión WhatsApp (QR/status por Socket.io).' },
          { method: 'DELETE', path: '/api/whatsapps/:whatsappId', auth: 'jwt', desc: 'Eliminar conexión WhatsApp.' },
          { method: 'GET', path: '/api/saved-replies', auth: 'jwt', desc: 'Listar respuestas rápidas.' },
          { method: 'POST', path: '/api/saved-replies', auth: 'jwt', desc: 'Crear respuesta rápida (shortcut/message).' },
          { method: 'PUT', path: '/api/saved-replies/:id', auth: 'jwt', desc: 'Editar respuesta rápida.' },
          { method: 'DELETE', path: '/api/saved-replies/:id', auth: 'jwt', desc: 'Eliminar respuesta rápida.' }
        ]
      },
      {
        group: 'Integraciones externas (API Key)',
        items: [
          {
            method: 'POST',
            path: '/api/integrations/leads',
            auth: 'x-api-key',
            desc: 'Crear lead desde otra plataforma (crea contacto + ticket).'
          },
          {
            method: 'POST',
            path: '/api/integrations/messages',
            auth: 'x-api-key',
            desc: 'Enviar mensaje saliente a un número (WhatsApp).'
          }
        ]
      }
    ],
    []
  );

  useEffect(() => {
    (async () => {
      setLoadingHealth(true);
      try {
        const { data } = await api.get('/health');
        setHealth(data);
      } catch {
        setHealth(null);
      } finally {
        setLoadingHealth(false);
      }
    })();
  }, [])

  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get('/settings/integrations/api-key');
        if (data?.apiKey) setIntegrationKey(data.apiKey);
      } catch {
        // ignore
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get('/settings/whatsapp-cloud');
        const s = data?.settings || {};
        setWaCloudVerifyToken(s.waCloudVerifyToken || '');
        setWaCloudPhoneNumberId(s.waCloudPhoneNumberId || '');
        setWaCloudAccessToken(s.waCloudAccessToken || '');
        setWaCloudAppSecret(s.waCloudAppSecret || '');
        setWaCloudDefaultWhatsappId(String(s.waCloudDefaultWhatsappId || 1));
      } catch {
        // ignore
      }
    })();
  }, []);


  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // ignore
    }
  };

  const handleSaveWaCloud = async () => {
    setSavingWaCloud(true);
    try {
      await api.put('/settings/whatsapp-cloud', {
        waCloudVerifyToken,
        waCloudPhoneNumberId,
        waCloudAccessToken,
        waCloudAppSecret,
        waCloudDefaultWhatsappId: Number(waCloudDefaultWhatsappId || 1)
      });
    } finally {
      setSavingWaCloud(false);
    }
  };

  const curlExamples = useMemo(() => {
    const key = integrationKey || '<INTEGRATIONS_API_KEY>';
    const base = hostBase || 'https://login.charlott.ai';
    return {
      lead: `curl -X POST '${base}/api/integrations/leads' \\\n  -H 'Content-Type: application/json' \\\n  -H 'x-api-key: ${key}' \\\n  -d '{"name":"Juan Perez","number":"+54 11 1234 5678","email":"juan@email.com","source":"meta_ads","notes":"Form Lead"}'`,
      msg: `curl -X POST '${base}/api/integrations/messages' \\\n  -H 'Content-Type: application/json' \\\n  -H 'x-api-key: ${key}' \\\n  -d '{"to":"+54 11 1234 5678","text":"Hola! Te contacto por tu consulta."}'`
    };
  }, [hostBase, integrationKey]);

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Configuración
      </Typography>

      <Paper sx={{ p: 2 }}>
        <Tabs value={tab} onChange={(_, v) => setTab(v)} variant="scrollable" scrollButtons="auto">
          <Tab label="Estado" />
          <Tab label="Endpoints" />
          <Tab label="Integraciones" />
          <Tab label="WhatsApp Cloud" />
          <Tab label="Variables" />
        </Tabs>
        <Divider sx={{ my: 2 }} />

        {tab === 0 && (
          <Stack spacing={2}>
            <Box>
              <Typography variant="h6">Estado del sistema</Typography>
              <Divider sx={{ my: 1 }} />
              <Typography variant="body2">API base: {apiBase}</Typography>
              <Typography variant="body2">Host base: {hostBase}</Typography>
            </Box>

            <Box>
              <Typography variant="subtitle2">Health</Typography>
              <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
                <Chip size="small" label={loadingHealth ? 'Verificando…' : health ? 'OK' : 'ERROR'} color={health ? 'success' : 'error'} />
                <Typography variant="body2" sx={{ opacity: 0.8 }}>
                  {health ? health.timestamp : 'No disponible'}
                </Typography>
              </Stack>
              <CodeBlock text={health ? JSON.stringify(health, null, 2) : 'No disponible'} />
            </Box>
          </Stack>
        )}

        {tab === 1 && (
          <Stack spacing={2}>
            <Typography variant="h6">Documentación de Endpoints</Typography>
            <Typography variant="body2" sx={{ opacity: 0.85 }}>
              Convenciones de autenticación:
              {' '}<b>jwt</b> = header <code>Authorization: Bearer &lt;token&gt;</code>.
              {' '}<b>x-api-key</b> = header <code>x-api-key: &lt;INTEGRATIONS_API_KEY&gt;</code>.
            </Typography>

            {endpoints.map((g) => (
              <Paper key={g.group} variant="outlined" sx={{ p: 2 }}>
                <Typography variant="subtitle1" sx={{ mb: 1 }}>{g.group}</Typography>
                <Stack spacing={1}>
                  {g.items.map((it) => (
                    <Box key={`${it.method}-${it.path}`} sx={{ display: 'flex', gap: 1, alignItems: 'baseline' }}>
                      <Chip size="small" label={it.method} color={it.method === 'GET' ? 'info' : it.method === 'POST' ? 'success' : it.method === 'PUT' ? 'warning' : 'error'} />
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="body2"><code>{it.path}</code></Typography>
                        <Typography variant="caption" sx={{ opacity: 0.8 }}>{it.desc}</Typography>
                      </Box>
                      <Chip size="small" variant="outlined" label={it.auth} />
                    </Box>
                  ))}
                </Stack>
              </Paper>
            ))}
          </Stack>
        )}

        {tab === 2 && (
          <Stack spacing={2}>
            <Typography variant="h6">Integraciones (n8n / Make / Zapier / Formularios)</Typography>

            <Paper variant="outlined" sx={{ p: 2 }}>
              <Typography variant="subtitle1">API Key</Typography>
              <Typography variant="caption" sx={{ opacity: 0.8 }}>
                Por seguridad, la key se muestra enmascarada. Pegá la key acá para generar ejemplos de CURL.
              </Typography>
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} sx={{ mt: 1 }} alignItems="center">
                <TextField
                  fullWidth
                  label="INTEGRATIONS_API_KEY"
                  value={integrationKey}
                  onChange={(e) => setIntegrationKey(e.target.value)}
                  placeholder="mA1thx8RrE-iU5x..."
                />
                <Button variant="outlined" onClick={() => setShowKey((s) => !s)}>
                  {showKey ? 'Ocultar' : 'Mostrar'}
                </Button>
              </Stack>
              {integrationKey && (
                <Typography variant="body2" sx={{ mt: 1 }}>
                  Key actual (preview): <code>{showKey ? integrationKey : mask(integrationKey)}</code>
                </Typography>
              )}
            </Paper>

            <Paper variant="outlined" sx={{ p: 2 }}>
              <Typography variant="subtitle1">Ejemplo: Crear Lead</Typography>
              <Stack direction="row" spacing={1} sx={{ mb: 1 }}>
                <Button size="small" variant="outlined" onClick={() => handleCopy(curlExamples.lead)}>Copiar</Button>
              </Stack>
              <CodeBlock text={curlExamples.lead} />
            </Paper>

            <Paper variant="outlined" sx={{ p: 2 }}>
              <Typography variant="subtitle1">Ejemplo: Enviar Mensaje</Typography>
              <Stack direction="row" spacing={1} sx={{ mb: 1 }}>
                <Button size="small" variant="outlined" onClick={() => handleCopy(curlExamples.msg)}>Copiar</Button>
              </Stack>
              <CodeBlock text={curlExamples.msg} />
            </Paper>
          </Stack>
        )}

        {tab === 3 && (
          <Stack spacing={2}>
            <Typography variant="h6">WhatsApp Cloud API</Typography>
            <Typography variant="body2" sx={{ opacity: 0.85 }}>
              Configurá acá tus credenciales de Meta. Se guardan en runtime-settings.json del backend.
            </Typography>

            <Paper variant="outlined" sx={{ p: 2 }}>
              <Stack spacing={1.5}>
                <TextField
                  label="Verify Token"
                  value={waCloudVerifyToken}
                  onChange={(e) => setWaCloudVerifyToken(e.target.value)}
                  fullWidth
                />
                <TextField
                  label="Phone Number ID"
                  value={waCloudPhoneNumberId}
                  onChange={(e) => setWaCloudPhoneNumberId(e.target.value)}
                  fullWidth
                />
                <TextField
                  label="Default WhatsApp ID (CRM)"
                  value={waCloudDefaultWhatsappId}
                  onChange={(e) => setWaCloudDefaultWhatsappId(e.target.value)}
                  fullWidth
                />
                <TextField
                  label="Access Token"
                  value={waCloudAccessToken}
                  onChange={(e) => setWaCloudAccessToken(e.target.value)}
                  type={showWaSecrets ? 'text' : 'password'}
                  fullWidth
                />
                <TextField
                  label="App Secret (opcional)"
                  value={waCloudAppSecret}
                  onChange={(e) => setWaCloudAppSecret(e.target.value)}
                  type={showWaSecrets ? 'text' : 'password'}
                  fullWidth
                />
                <Stack direction="row" spacing={1}>
                  <Button variant="outlined" onClick={() => setShowWaSecrets((s) => !s)}>
                    {showWaSecrets ? 'Ocultar secretos' : 'Mostrar secretos'}
                  </Button>
                  <Button variant="contained" onClick={handleSaveWaCloud} disabled={savingWaCloud}>
                    {savingWaCloud ? 'Guardando…' : 'Guardar configuración'}
                  </Button>
                </Stack>
              </Stack>
            </Paper>

            <Paper variant="outlined" sx={{ p: 2 }}>
              <Typography variant="subtitle2">Webhook URL para Meta</Typography>
              <CodeBlock text={`${hostBase || 'https://login.charlott.ai'}/api/whatsapp-cloud/webhook`} />
            </Paper>
          </Stack>
        )}

        {tab === 4 && (
          <Stack spacing={2}>
            <Typography variant="h6">Variables / Configuración posible</Typography>
            <Typography variant="body2" sx={{ opacity: 0.85 }}>
              Estas variables se configuran en el VPS (PM2 ecosystem) y controlan el comportamiento del backend.
            </Typography>
            <Paper variant="outlined" sx={{ p: 2 }}>
              <Typography variant="subtitle2">Aplicación</Typography>
              <CodeBlock text={[
                'NODE_ENV=production',
                'PORT=4000',
                'FRONTEND_URL=https://login.charlott.ai'
              ].join('\n')} />
            </Paper>
            <Paper variant="outlined" sx={{ p: 2 }}>
              <Typography variant="subtitle2">Base de datos (PostgreSQL)</Typography>
              <CodeBlock text={[
                'DB_HOST=127.0.0.1',
                'DB_PORT=5432',
                'DB_NAME=atendechat',
                'DB_USER=atendechat_user',
                'DB_PASS=********'
              ].join('\n')} />
            </Paper>
            <Paper variant="outlined" sx={{ p: 2 }}>
              <Typography variant="subtitle2">JWT / Sesiones</Typography>
              <CodeBlock text={[
                'JWT_SECRET=<secret>',
                'JWT_EXPIRES_IN=1d',
                'JWT_REFRESH_SECRET=<secret>',
                'JWT_REFRESH_EXPIRES_IN=7d'
              ].join('\n')} />
            </Paper>
            <Paper variant="outlined" sx={{ p: 2 }}>
              <Typography variant="subtitle2">Integraciones — API Key</Typography>
              <Typography variant="caption" sx={{ opacity: 0.8 }}>
                Esta key se usa para autenticar llamadas a <code>/api/integrations/*</code> vía header <code>x-api-key</code>.
              </Typography>

              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1} sx={{ mt: 1 }} alignItems="center">
                <TextField
                  fullWidth
                  label="INTEGRATIONS_API_KEY"
                  value={showKey ? integrationKey : mask(integrationKey)}
                  placeholder="(no configurada)"
                  InputProps={{ readOnly: true }}
                />
                <Button variant="outlined" onClick={() => setShowKey((s) => !s)} disabled={!integrationKey}>
                  {showKey ? 'Ocultar' : 'Mostrar'}
                </Button>
                <Button
                  variant="contained"
                  onClick={() => handleCopy(integrationKey)}
                  disabled={!integrationKey}
                >
                  Copiar
                </Button>
              </Stack>

              <Divider sx={{ my: 2 }} />
              <CodeBlock text={[
                'INTEGRATIONS_API_KEY=<secret>',
                '',
                'Header requerido: x-api-key: <INTEGRATIONS_API_KEY>'
              ].join('\n')} />
            </Paper>
          </Stack>
        )}
      </Paper>
    </Box>
  );
};

export default Settings;

import { useEffect, useMemo, useState } from 'react';
import {
  Typography,
  Box,
  Paper,
  Stack,
  TextField,
  Button,
  Grid,
  Chip,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import { Add as AddIcon, Upload as UploadIcon, Sync as SyncIcon, Search as SearchIcon } from '@mui/icons-material';
import { toast } from 'react-toastify';
import api from '../../services/api';

const Knowledge = () => {
  const [stats, setStats] = useState({ total: 0, synced: 0, pending: 0, categories: 0 });
  const [docs, setDocs] = useState<any[]>([]);

  const [q, setQ] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const [openNew, setOpenNew] = useState(false);
  const [title, setTitle] = useState('Información General');
  const [category, setCategory] = useState('general');
  const [content, setContent] = useState('Descripción de servicios, precios, políticas y FAQ.');
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      const [s, d] = await Promise.all([
        api.get('/ai/kb/stats'),
        api.get('/ai/kb/documents', { params: { q, category: categoryFilter, status: statusFilter } })
      ]);
      setStats(s.data || { total: 0, synced: 0, pending: 0, categories: 0 });
      setDocs(Array.isArray(d.data) ? d.data : []);
    } catch {
      toast.error('No se pudo cargar conocimiento');
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const createDoc = async () => {
    if (!title.trim() || !content.trim()) {
      toast.error('Completá título y contenido');
      return;
    }

    setSaving(true);
    try {
      await api.post('/ai/kb/documents', { title, category, content });
      toast.success('Documento creado');
      setOpenNew(false);
      setContent('');
      await load();
    } catch (e: any) {
      toast.error(e?.response?.data?.error || 'No se pudo crear documento');
    } finally {
      setSaving(false);
    }
  };

  const cards = useMemo(
    () => [
      { title: 'Total Documentos', value: stats.total },
      { title: 'Sincronizados', value: stats.synced },
      { title: 'Pendientes', value: stats.pending },
      { title: 'Categorías', value: stats.categories }
    ],
    [stats]
  );

  return (
    <Box>
      <Stack direction='row' justifyContent='space-between' alignItems='center' sx={{ mb: 1 }}>
        <Box>
          <Typography variant='h4'>Base de Conocimiento</Typography>
          <Typography variant='body2' color='text.secondary'>
            Administrá la información que tu agente IA utiliza para responder a los clientes.
          </Typography>
        </Box>
        <Stack direction='row' spacing={1}>
          <Button variant='outlined'>Guía</Button>
          <Button variant='outlined' startIcon={<SearchIcon />}>Probar búsqueda</Button>
          <Button variant='outlined' startIcon={<SyncIcon />} onClick={load}>Sincronizar</Button>
          <Button variant='outlined' startIcon={<UploadIcon />}>Subir Archivo</Button>
          <Button variant='contained' startIcon={<AddIcon />} onClick={() => setOpenNew(true)}>Nuevo</Button>
        </Stack>
      </Stack>

      <Grid container spacing={2} sx={{ mb: 2 }}>
        {cards.map((c) => (
          <Grid item xs={12} md={3} key={c.title}>
            <Paper sx={{ p: 2 }}>
              <Typography variant='caption' color='text.secondary'>{c.title}</Typography>
              <Typography variant='h5'>{c.value}</Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Paper sx={{ p: 2, mb: 2 }}>
        <Stack direction='row' spacing={1.5}>
          <TextField fullWidth placeholder='Buscar por título o contenido...' value={q} onChange={(e) => setQ(e.target.value)} />
          <TextField select label='Categoría' value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} sx={{ minWidth: 170 }}>
            <MenuItem value=''>Todas las categorías</MenuItem>
            <MenuItem value='general'>general</MenuItem>
            <MenuItem value='faq'>faq</MenuItem>
            <MenuItem value='precios'>precios</MenuItem>
            <MenuItem value='casos_uso'>casos_uso</MenuItem>
          </TextField>
          <TextField select label='Estado' value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} sx={{ minWidth: 140 }}>
            <MenuItem value=''>Todos</MenuItem>
            <MenuItem value='ready'>Sincronizado</MenuItem>
          </TextField>
          <Button variant='outlined' onClick={load}>Filtrar</Button>
        </Stack>
      </Paper>

      <Grid container spacing={2}>
        {docs.map((d: any) => (
          <Grid item xs={12} md={4} key={d.id}>
            <Paper variant='outlined' sx={{ p: 1.5, minHeight: 140 }}>
              <Stack direction='row' justifyContent='space-between' sx={{ mb: 1 }}>
                <Chip size='small' label={d.category || 'general'} />
                <Typography variant='caption' color='text.secondary'>
                  {d.status === 'ready' ? 'Sincronizado' : d.status}
                </Typography>
              </Stack>
              <Typography variant='subtitle2' sx={{ mb: 0.5 }}>{d.title}</Typography>
              <Typography variant='caption' color='text.secondary'>Chunks: {d.chunks}</Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Dialog open={openNew} onClose={() => setOpenNew(false)} maxWidth='sm' fullWidth>
        <DialogTitle>Nuevo documento</DialogTitle>
        <DialogContent>
          <Stack spacing={1.5} sx={{ mt: 1 }}>
            <TextField label='Título' value={title} onChange={(e) => setTitle(e.target.value)} />
            <TextField select label='Categoría' value={category} onChange={(e) => setCategory(e.target.value)}>
              <MenuItem value='general'>general</MenuItem>
              <MenuItem value='faq'>faq</MenuItem>
              <MenuItem value='precios'>precios</MenuItem>
              <MenuItem value='casos_uso'>casos_uso</MenuItem>
            </TextField>
            <TextField label='Contenido' multiline minRows={6} value={content} onChange={(e) => setContent(e.target.value)} />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenNew(false)}>Cancelar</Button>
          <Button variant='contained' onClick={createDoc} disabled={saving}>{saving ? 'Guardando...' : 'Crear'}</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Knowledge;

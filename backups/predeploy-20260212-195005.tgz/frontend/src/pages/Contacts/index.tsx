import {
  Typography,
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  Stack,
  Chip,
  MenuItem,
  Grid
} from '@mui/material';
import { Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { useEffect, useMemo, useState } from 'react';
import { toast } from 'react-toastify';
import api from '../../services/api';

type LeadStatus = 'unread' | 'read' | 'waiting';

interface Lead {
  id: number;
  name: string;
  number: string;
  email: string;
  source?: string;
  leadStatus?: LeadStatus;
  business_type?: string;
  needs?: string;
  lead_score?: number;
  createdAt: string;
  updatedAt: string;
}

const statusLabel: Record<LeadStatus, string> = {
  unread: 'Nuevo',
  read: 'Leído',
  waiting: 'Esperando'
};

const statusColor: Record<LeadStatus, any> = {
  unread: 'info',
  read: 'default',
  waiting: 'warning'
};

const Leads = () => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<LeadStatus | 'all'>('all');

  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState<Lead | null>(null);

  const [name, setName] = useState('');
  const [number, setNumber] = useState('');
  const [email, setEmail] = useState('');
  const [source, setSource] = useState('');
  const [leadStatus, setLeadStatus] = useState<LeadStatus>('unread');

  const fetchLeads = async () => {
    setLoading(true);
    try {
      const params: any = {};
      if (filterStatus !== 'all') params.status = filterStatus;
      const { data } = await api.get('/contacts', { params });
      setLeads(Array.isArray(data) ? data : []);
    } catch {
      toast.error('Error al cargar leads');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeads();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterStatus]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return leads;
    return leads.filter((l) => [l.name || '', l.number || '', l.email || '', l.source || ''].join(' ').toLowerCase().includes(q));
  }, [leads, search]);

  const stats = useMemo(() => {
    const total = leads.length;
    const nuevos = leads.filter((l) => (l.leadStatus || 'unread') === 'unread').length;
    const esperando = leads.filter((l) => (l.leadStatus || 'unread') === 'waiting').length;
    const calientes = leads.filter((l) => Number(l.lead_score || 0) >= 70).length;
    return { total, nuevos, esperando, calientes };
  }, [leads]);

  const resetForm = () => {
    setName('');
    setNumber('');
    setEmail('');
    setSource('');
    setLeadStatus('unread');
    setEditing(null);
  };

  const openCreate = () => {
    resetForm();
    setOpen(true);
  };

  const openEdit = (lead: Lead) => {
    setEditing(lead);
    setName(lead.name || '');
    setNumber(lead.number || '');
    setEmail(lead.email || '');
    setSource(lead.source || '');
    setLeadStatus((lead.leadStatus as LeadStatus) || 'unread');
    setOpen(true);
  };

  const saveLead = async () => {
    if (!name.trim() || !number.trim()) {
      toast.error('Nombre y número son obligatorios');
      return;
    }

    setSaving(true);
    try {
      const payload = { name: name.trim(), number: number.trim(), email: email.trim(), source: source.trim() || null, leadStatus };
      if (editing) {
        await api.put(`/contacts/${editing.id}`, payload);
        toast.success('Lead actualizado');
      } else {
        await api.post('/contacts', payload);
        toast.success('Lead creado');
      }
      setOpen(false);
      fetchLeads();
    } catch (e: any) {
      toast.error(e?.response?.data?.error || 'No se pudo guardar');
    } finally {
      setSaving(false);
    }
  };

  const removeLead = async (lead: Lead) => {
    if (!window.confirm(`¿Eliminar lead ${lead.name}?`)) return;
    try {
      await api.delete(`/contacts/${lead.id}`);
      toast.success('Lead eliminado');
      fetchLeads();
    } catch {
      toast.error('No se pudo eliminar');
    }
  };

  return (
    <Box>
      <Stack direction='row' justifyContent='space-between' alignItems='center' sx={{ mb: 1 }}>
        <Box>
          <Typography variant='h4'>Leads</Typography>
          <Typography variant='body2' color='text.secondary'>Gestión comercial de clientes potenciales.</Typography>
        </Box>
        <Button variant='contained' startIcon={<AddIcon />} onClick={openCreate}>Nuevo Lead</Button>
      </Stack>

      <Grid container spacing={2} sx={{ mb: 2 }}>
        <Grid item xs={12} md={3}><Paper sx={{ p: 2 }}><Typography variant='caption'>Total</Typography><Typography variant='h5'>{stats.total}</Typography></Paper></Grid>
        <Grid item xs={12} md={3}><Paper sx={{ p: 2 }}><Typography variant='caption'>Nuevos</Typography><Typography variant='h5'>{stats.nuevos}</Typography></Paper></Grid>
        <Grid item xs={12} md={3}><Paper sx={{ p: 2 }}><Typography variant='caption'>Esperando</Typography><Typography variant='h5'>{stats.esperando}</Typography></Paper></Grid>
        <Grid item xs={12} md={3}><Paper sx={{ p: 2 }}><Typography variant='caption'>Calientes (score ≥ 70)</Typography><Typography variant='h5'>{stats.calientes}</Typography></Paper></Grid>
      </Grid>

      <Paper sx={{ p: 2, mb: 2 }}>
        <Stack direction='row' spacing={1.5}>
          <TextField fullWidth label='Buscar por nombre, número, email o fuente' value={search} onChange={(e) => setSearch(e.target.value)} />
          <TextField select label='Estado' value={filterStatus} onChange={(e) => setFilterStatus(e.target.value as any)} sx={{ minWidth: 170 }}>
            <MenuItem value='all'>Todos</MenuItem>
            <MenuItem value='unread'>Nuevo</MenuItem>
            <MenuItem value='waiting'>Esperando</MenuItem>
            <MenuItem value='read'>Leído</MenuItem>
          </TextField>
        </Stack>
      </Paper>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Lead</TableCell>
                <TableCell>Contacto</TableCell>
                <TableCell>Estado</TableCell>
                <TableCell>Score</TableCell>
                <TableCell>Fuente</TableCell>
                <TableCell>Actualizado</TableCell>
                <TableCell align='right'>Acciones</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={7} align='center'>Cargando...</TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={7} align='center'>Sin leads</TableCell></TableRow>
              ) : (
                filtered.map((l) => {
                  const st = (l.leadStatus || 'unread') as LeadStatus;
                  return (
                    <TableRow key={l.id} hover>
                      <TableCell>
                        <Typography variant='body2' sx={{ fontWeight: 600 }}>{l.name}</Typography>
                        <Typography variant='caption' color='text.secondary'>{l.business_type || '-'}</Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant='body2'>{l.number}</Typography>
                        <Typography variant='caption' color='text.secondary'>{l.email || '-'}</Typography>
                      </TableCell>
                      <TableCell><Chip size='small' color={statusColor[st]} label={statusLabel[st]} /></TableCell>
                      <TableCell>{Number(l.lead_score || 0)}%</TableCell>
                      <TableCell>{l.source || '-'}</TableCell>
                      <TableCell>{new Date(l.updatedAt).toLocaleString()}</TableCell>
                      <TableCell align='right'>
                        <IconButton size='small' onClick={() => openEdit(l)}><EditIcon fontSize='small' /></IconButton>
                        <IconButton size='small' color='error' onClick={() => removeLead(l)}><DeleteIcon fontSize='small' /></IconButton>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth='sm' fullWidth>
        <DialogTitle>{editing ? 'Editar lead' : 'Nuevo lead'}</DialogTitle>
        <DialogContent>
          <Stack spacing={1.5} sx={{ mt: 1 }}>
            <TextField label='Nombre' value={name} onChange={(e) => setName(e.target.value)} />
            <TextField label='Número' value={number} onChange={(e) => setNumber(e.target.value)} />
            <TextField label='Email' value={email} onChange={(e) => setEmail(e.target.value)} />
            <TextField label='Fuente' value={source} onChange={(e) => setSource(e.target.value)} />
            <TextField select label='Estado del lead' value={leadStatus} onChange={(e) => setLeadStatus(e.target.value as LeadStatus)}>
              <MenuItem value='unread'>Nuevo</MenuItem>
              <MenuItem value='waiting'>Esperando</MenuItem>
              <MenuItem value='read'>Leído</MenuItem>
            </TextField>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancelar</Button>
          <Button variant='contained' onClick={saveLead} disabled={saving}>{saving ? 'Guardando...' : 'Guardar'}</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Leads;

import { useEffect, useState } from 'react';
import {
  Typography,
  Box,
  Paper,
  Stack,
  TextField,
  Button,
  Divider,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Chip
} from '@mui/material';
import { toast } from 'react-toastify';
import api from '../../services/api';

const AIAgents = () => {
  const [agents, setAgents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const [name, setName] = useState('Agente Ventas');
  const [persona, setPersona] = useState('Asistente comercial, claro y persuasivo.');
  const [model, setModel] = useState('gpt-4o-mini');

  const [docTitle, setDocTitle] = useState('FAQ Ventas');
  const [docCategory, setDocCategory] = useState('faq');
  const [docContent, setDocContent] = useState('Pregunta: precio\nRespuesta: depende del plan.');

  const [searchQuery, setSearchQuery] = useState('precio');
  const [searchResults, setSearchResults] = useState<any[]>([]);

  const fetchAgents = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/ai/agents');
      setAgents(Array.isArray(data) ? data : []);
    } catch {
      toast.error('No se pudo cargar agentes IA');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAgents();
  }, []);

  const createAgent = async () => {
    try {
      await api.post('/ai/agents', { name, persona, model, language: 'es' });
      toast.success('Agente creado');
      fetchAgents();
    } catch {
      toast.error('No se pudo crear agente');
    }
  };

  const toggleAgent = async (agent: any) => {
    try {
      await api.put(`/ai/agents/${agent.id}`, { isActive: !agent.is_active });
      toast.success('Estado de agente actualizado');
      fetchAgents();
    } catch {
      toast.error('No se pudo actualizar agente');
    }
  };

  const createKbDoc = async () => {
    try {
      const { data } = await api.post('/ai/kb/documents', {
        title: docTitle,
        category: docCategory,
        content: docContent
      });
      toast.success(`Documento creado (${data?.chunksCreated || 0} chunks)`);
    } catch {
      toast.error('No se pudo crear documento KB');
    }
  };

  const searchKb = async () => {
    try {
      const { data } = await api.post('/ai/rag/search', { query: searchQuery, limit: 5 });
      setSearchResults(Array.isArray(data) ? data : []);
      toast.success('Búsqueda RAG ejecutada');
    } catch {
      toast.error('No se pudo buscar en KB');
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>Agentes IA</Typography>

      <Stack spacing={2}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6">Crear agente</Typography>
          <Stack spacing={1.5} sx={{ mt: 1 }}>
            <TextField label="Nombre" value={name} onChange={(e) => setName(e.target.value)} />
            <TextField label="Persona" value={persona} onChange={(e) => setPersona(e.target.value)} multiline minRows={2} />
            <TextField label="Modelo" value={model} onChange={(e) => setModel(e.target.value)} />
            <Button variant="contained" onClick={createAgent}>Crear agente</Button>
          </Stack>
        </Paper>

        <Paper sx={{ p: 2 }}>
          <Typography variant="h6">Agentes existentes</Typography>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Nombre</TableCell>
                <TableCell>Modelo</TableCell>
                <TableCell>Estado</TableCell>
                <TableCell>Acción</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={5}>Cargando...</TableCell></TableRow>
              ) : agents.length === 0 ? (
                <TableRow><TableCell colSpan={5}>Sin agentes</TableCell></TableRow>
              ) : agents.map((a) => (
                <TableRow key={a.id}>
                  <TableCell>{a.id}</TableCell>
                  <TableCell>{a.name}</TableCell>
                  <TableCell>{a.model}</TableCell>
                  <TableCell>
                    <Chip size="small" color={a.is_active ? 'success' : 'default'} label={a.is_active ? 'Activo' : 'Inactivo'} />
                  </TableCell>
                  <TableCell>
                    <Button size="small" onClick={() => toggleAgent(a)}>
                      {a.is_active ? 'Desactivar' : 'Activar'}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Paper>

        <Paper sx={{ p: 2 }}>
          <Typography variant="h6">Base de conocimiento (RAG)</Typography>
          <Stack spacing={1.5} sx={{ mt: 1 }}>
            <TextField label="Título" value={docTitle} onChange={(e) => setDocTitle(e.target.value)} />
            <TextField label="Categoría" value={docCategory} onChange={(e) => setDocCategory(e.target.value)} />
            <TextField label="Contenido" value={docContent} onChange={(e) => setDocContent(e.target.value)} multiline minRows={4} />
            <Button variant="contained" onClick={createKbDoc}>Cargar documento</Button>
          </Stack>

          <Divider sx={{ my: 2 }} />

          <Stack direction="row" spacing={1.5}>
            <TextField fullWidth label="Buscar en conocimiento" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
            <Button variant="outlined" onClick={searchKb}>Buscar</Button>
          </Stack>

          <Stack spacing={1} sx={{ mt: 2 }}>
            {searchResults.map((r, idx) => (
              <Paper key={idx} variant="outlined" sx={{ p: 1.25 }}>
                <Typography variant="caption">{r.title} · {r.category} · score {Number(r.score || r.similarity || 0).toFixed(2)}</Typography>
                <Typography variant="body2">{r.chunk_text}</Typography>
              </Paper>
            ))}
          </Stack>
        </Paper>
      </Stack>
    </Box>
  );
};

export default AIAgents;

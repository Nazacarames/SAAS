import { Routes as RouterRoutes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '../context/Auth/AuthContext';
import Login from '../pages/Login';
import Dashboard from '../pages/Dashboard';
import Tickets from '../pages/Tickets';
import Conversations from '../pages/Conversations';
import Contacts from '../pages/Contacts';
import Connections from '../pages/Connections';
import Users from '../pages/Users';
import Queues from '../pages/Queues';
import Integrations from '../pages/Integrations';
import Settings from '../pages/Settings';
import AIAgents from '../pages/AIAgents';
import MainLayout from '../layout/MainLayout';

const PrivateRoute = ({ children }: { children: JSX.Element }) => {
    const { isAuth, loading } = useAuth();

    if (loading) {
        return <div>Cargando...</div>;
    }

    return isAuth ? children : <Navigate to="/login" />;
};

const Routes = () => {
    const { isAuth } = useAuth();

    return (
        <RouterRoutes>
            <Route
                path="/login"
                element={isAuth ? <Navigate to="/" /> : <Login />}
            />

            <Route
                path="/"
                element={
                    <PrivateRoute>
                        <MainLayout />
                    </PrivateRoute>
                }
            >
                <Route index element={<Dashboard />} />
                <Route path="tickets" element={<Tickets />} />
                <Route path="conversations" element={<Conversations />} />
                <Route path="contacts" element={<Contacts />} />
                <Route path="connections" element={<Connections />} />
                <Route path="users" element={<Users />} />
                <Route path="queues" element={<Queues />} />
                <Route path="integrations" element={<Integrations />} />
                <Route path="settings" element={<Settings />} />
                <Route path="ai-agents" element={<AIAgents />} />
            </Route>

            <Route path="*" element={<Navigate to="/" />} />
        </RouterRoutes>
    );
};

export default Routes;

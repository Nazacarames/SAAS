import {
    Drawer,
    List,
    ListItem,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Toolbar,
    Typography,
    Box,
    Divider
} from '@mui/material';
import {
    Dashboard as DashboardIcon,
    Chat as ChatIcon,
    Contacts as ContactsIcon,
    WhatsApp as WhatsAppIcon,
    People as PeopleIcon,
    Queue as QueueIcon,
    Settings as SettingsIcon,
    SmartToy as SmartToyIcon,
    Logout as LogoutIcon
} from '@mui/icons-material';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/Auth/AuthContext';

const drawerWidth = 240;

const Sidebar = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const { handleLogout, user } = useAuth();
    const isAdmin = user?.profile === "admin";

    const menuItems = [
        { text: 'Dashboard', icon: <DashboardIcon />, path: '/' },
        { text: 'Conversaciones', icon: <ChatIcon />, path: '/conversations' },
        { text: 'Tickets', icon: <ChatIcon />, path: '/tickets' },
        { text: 'Leads', icon: <ContactsIcon />, path: '/contacts' },
        { text: 'Conexiones', icon: <WhatsAppIcon />, path: '/connections' },
        { text: 'Usuarios', icon: <PeopleIcon />, path: '/users', adminOnly: true },
        { text: 'Colas', icon: <QueueIcon />, path: '/queues', adminOnly: true },
        { text: 'Integraciones', icon: <SettingsIcon />, path: '/integrations', adminOnly: true },
        { text: 'Configuración', icon: <SettingsIcon />, path: '/settings', adminOnly: true },
        { text: 'Agentes IA', icon: <SmartToyIcon />, path: '/ai-agents', adminOnly: true },
    ];

    const drawer = (
        <Box>
            <Toolbar>
                <Typography variant="h6" noWrap component="div">
                    LMTM CRM
                </Typography>
            </Toolbar>
            <Divider />
            <List>
                {menuItems.filter((i: any) => isAdmin || !i.adminOnly).map((item) => (
                    <ListItem key={item.text} disablePadding>
                        <ListItemButton
                            selected={location.pathname === item.path}
                            onClick={() => navigate(item.path)}
                        >
                            <ListItemIcon>{item.icon}</ListItemIcon>
                            <ListItemText primary={item.text} />
                        </ListItemButton>
                    </ListItem>
                ))}
            </List>
            <Divider />
            <List>
                <ListItem disablePadding>
                    <ListItemButton onClick={handleLogout}>
                        <ListItemIcon>
                            <LogoutIcon />
                        </ListItemIcon>
                        <ListItemText primary="Cerrar Sesión" />
                    </ListItemButton>
                </ListItem>
            </List>
            <Box sx={{ p: 2, mt: 'auto' }}>
                <Typography variant="caption" color="text.secondary">
                    Usuario: {user?.name}
                </Typography>
            </Box>
        </Box>
    );

    return (
        <Box
            component="nav"
            sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
        >
            <Drawer
                variant="permanent"
                sx={{
                    display: { xs: 'none', sm: 'block' },
                    '& .MuiDrawer-paper': { boxSizing: 'border-box', width: drawerWidth },
                }}
                open
            >
                {drawer}
            </Drawer>
        </Box>
    );
};

export default Sidebar;

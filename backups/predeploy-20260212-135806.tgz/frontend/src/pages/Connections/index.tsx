import {
  Typography,
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Button,
  TextField,
  Stack,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import api from '../../services/api';

interface WhatsAppConnection {
  id: number;
  name: string;
  status: string;
  battery?: number;
  isDefault: boolean;
}

const Connections = () => {
  const [connections, setConnections] = useState<WhatsAppConnection[]>([]);
  const [loading, setLoading] = useState(true);

  const [openNewConnection, setOpenNewConnection] = useState(false);
  const [waCloudVerifyToken, setWaCloudVerifyToken] = useState('');
  const [waCloudPhoneNumberId, setWaCloudPhoneNumberId] = useState('');
  const [waCloudAccessToken, setWaCloudAccessToken] = useState('');
  const [waCloudAppSecret, setWaCloudAppSecret] = useState('');
  const [waCloudDefaultWhatsappId, setWaCloudDefaultWhatsappId] = useState('1');
  const [showWaSecrets, setShowWaSecrets] = useState(false);
  const [savingWaCloud, setSavingWaCloud] = useState(false);

  useEffect(() => {
    fetchConnections();
    fetchCloudSettings();
  }, []);

  const fetchConnections = async () => {
    try {
      const { data } = await api.get('/whatsapps');
      setConnections(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error fetching connections:', error);
      toast.error('Error al cargar conexiones');
    } finally {
      setLoading(false);
    }
  };

  const fetchCloudSettings = async () => {
    try {
      const { data } = await api.get('/settings/whatsapp-cloud');
      const s = data?.settings || {};
      setWaCloudVerifyToken(s.waCloudVerifyToken || '');
      setWaCloudPhoneNumberId(s.waCloudPhoneNumberId || '');
      setWaCloudAccessToken(s.waCloudAccessToken || '');
      setWaCloudAppSecret(s.waCloudAppSecret || '');
      setWaCloudDefaultWhatsappId(String(s.waCloudDefaultWhatsappId || 1));
    } catch {
      // ignore
    }
  };

  const saveCloudSettings = async () => {
    setSavingWaCloud(true);
    try {
      await api.put('/settings/whatsapp-cloud', {
        waCloudVerifyToken,
        waCloudPhoneNumberId,
        waCloudAccessToken,
        waCloudAppSecret,
        waCloudDefaultWhatsappId: Number(waCloudDefaultWhatsappId || 1)
      });
      toast.success('Conexión Cloud API guardada');
      setOpenNewConnection(false);
      fetchConnections();
    } catch {
      toast.error('No se pudo guardar la conexión Cloud API');
    } finally {
      setSavingWaCloud(false);
    }
  };

  return (
    <Box>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h4">Conexiones WhatsApp</Typography>
        <Stack direction="row" spacing={1}>
          <Chip color="warning" label="QR deshabilitado" />
          <Button variant="contained" onClick={() => setOpenNewConnection(true)}>
            Nueva conexión
          </Button>
        </Stack>
      </Box>

      <Paper sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1">Modo activo: WhatsApp Cloud API</Typography>
        <Typography variant="body2" color="text.secondary">
          Para conectar, usá “Nueva conexión” y cargá las credenciales de Meta.
        </Typography>
        <Divider sx={{ my: 1.5 }} />
        <Typography variant="caption" color="text.secondary">
          Callback URL: https://login.charlott.ai/api/whatsapp-cloud/webhook
        </Typography>
      </Paper>

      <Paper>
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Nombre</TableCell>
                <TableCell>Estado</TableCell>
                <TableCell>Batería</TableCell>
                <TableCell>Predeterminada</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} align="center">Cargando...</TableCell>
                </TableRow>
              ) : connections.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} align="center">No hay conexiones registradas</TableCell>
                </TableRow>
              ) : (
                connections.map((conn) => (
                  <TableRow key={conn.id}>
                    <TableCell>{conn.id}</TableCell>
                    <TableCell>{conn.name}</TableCell>
                    <TableCell>{conn.status}</TableCell>
                    <TableCell>{conn.battery || 'N/A'}%</TableCell>
                    <TableCell>{conn.isDefault ? 'Sí' : 'No'}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>

      <Dialog open={openNewConnection} onClose={() => setOpenNewConnection(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Nueva conexión WhatsApp Cloud API</DialogTitle>
        <DialogContent>
          <Stack spacing={1.5} sx={{ mt: 1 }}>
            <TextField label="Verify Token" value={waCloudVerifyToken} onChange={(e) => setWaCloudVerifyToken(e.target.value)} fullWidth />
            <TextField label="Phone Number ID" value={waCloudPhoneNumberId} onChange={(e) => setWaCloudPhoneNumberId(e.target.value)} fullWidth />
            <TextField label="Default WhatsApp ID (CRM)" value={waCloudDefaultWhatsappId} onChange={(e) => setWaCloudDefaultWhatsappId(e.target.value)} fullWidth />
            <TextField
              label="Access Token"
              value={waCloudAccessToken}
              onChange={(e) => setWaCloudAccessToken(e.target.value)}
              type={showWaSecrets ? 'text' : 'password'}
              fullWidth
            />
            <TextField
              label="App Secret (opcional)"
              value={waCloudAppSecret}
              onChange={(e) => setWaCloudAppSecret(e.target.value)}
              type={showWaSecrets ? 'text' : 'password'}
              fullWidth
            />
            <Button variant="outlined" onClick={() => setShowWaSecrets((s) => !s)}>
              {showWaSecrets ? 'Ocultar secretos' : 'Mostrar secretos'}
            </Button>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenNewConnection(false)}>Cancelar</Button>
          <Button variant="contained" onClick={saveCloudSettings} disabled={savingWaCloud}>
            {savingWaCloud ? 'Guardando...' : 'Guardar conexión'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Connections;

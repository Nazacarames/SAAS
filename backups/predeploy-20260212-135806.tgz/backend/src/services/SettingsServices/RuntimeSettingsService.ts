import fs from "fs";
import path from "path";

export interface RuntimeSettings {
  waCloudVerifyToken: string;
  waCloudPhoneNumberId: string;
  waCloudAccessToken: string;
  waCloudAppSecret: string;
  waCloudDefaultWhatsappId: number;
}

const FILE_PATH = path.resolve(process.cwd(), "runtime-settings.json");

const readFileSettings = (): Partial<RuntimeSettings> => {
  try {
    if (!fs.existsSync(FILE_PATH)) return {};
    const raw = fs.readFileSync(FILE_PATH, "utf-8");
    const parsed = JSON.parse(raw || "{}");
    return parsed || {};
  } catch {
    return {};
  }
};

const writeFileSettings = (settings: Partial<RuntimeSettings>) => {
  fs.writeFileSync(FILE_PATH, JSON.stringify(settings, null, 2), "utf-8");
};

export const getRuntimeSettings = (): RuntimeSettings => {
  const fromFile = readFileSettings();

  const defaultWhatsappIdEnv = Number(process.env.WA_CLOUD_DEFAULT_WHATSAPP_ID || 1);
  const defaultWhatsappIdFile = Number((fromFile as any)?.waCloudDefaultWhatsappId || 0);

  return {
    waCloudVerifyToken:
      String((fromFile as any)?.waCloudVerifyToken || "") || process.env.WA_CLOUD_VERIFY_TOKEN || "",
    waCloudPhoneNumberId:
      String((fromFile as any)?.waCloudPhoneNumberId || "") || process.env.WA_CLOUD_PHONE_NUMBER_ID || "",
    waCloudAccessToken:
      String((fromFile as any)?.waCloudAccessToken || "") || process.env.WA_CLOUD_ACCESS_TOKEN || "",
    waCloudAppSecret:
      String((fromFile as any)?.waCloudAppSecret || "") || process.env.WA_CLOUD_APP_SECRET || "",
    waCloudDefaultWhatsappId:
      defaultWhatsappIdFile > 0 ? defaultWhatsappIdFile : (defaultWhatsappIdEnv > 0 ? defaultWhatsappIdEnv : 1)
  };
};

export const saveRuntimeSettings = (patch: Partial<RuntimeSettings>) => {
  const current = getRuntimeSettings();
  const next: RuntimeSettings = {
    ...current,
    ...patch,
    waCloudDefaultWhatsappId: Number(patch.waCloudDefaultWhatsappId || current.waCloudDefaultWhatsappId || 1)
  };

  writeFileSettings(next);
  return next;
};

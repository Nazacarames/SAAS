import crypto from "crypto";
import { Op } from "sequelize";

import Contact from "../../models/Contact";
import Ticket from "../../models/Ticket";
import Message from "../../models/Message";
import Whatsapp from "../../models/Whatsapp";
import { getIO } from "../../libs/socket";
import { recordInboundDuplicate, recordInboundError, recordInboundMessage } from "../../utils/messageStats";
import { getRuntimeSettings } from "../SettingsServices/RuntimeSettingsService";

type MetaWebhookPayload = {
  entry?: Array<{
    changes?: Array<{
      value?: {
        messages?: Array<{
          id?: string;
          from?: string;
          timestamp?: string;
          type?: string;
          text?: { body?: string };
        }>;
      };
    }>;
  }>;
};

const resolveWhatsapp = async () => {
  const runtime = getRuntimeSettings();
  const preferredId = Number(runtime.waCloudDefaultWhatsappId || 0);
  if (preferredId > 0) {
    const byId = await Whatsapp.findByPk(preferredId);
    if (byId) return byId;
  }

  const byDefault = await Whatsapp.findOne({ where: { isDefault: true } });
  if (byDefault) return byDefault;

  const anyWhatsapp = await Whatsapp.findOne();
  if (anyWhatsapp) return anyWhatsapp;

  // Auto-create a Cloud connection if none exists (companyId=1 by convention).
  return Whatsapp.create({
    name: "WhatsApp Cloud",
    status: "CONNECTED",
    isDefault: true,
    companyId: 1
  } as any);
};

const getOrCreateContact = async (phone: string, companyId: number) => {
  let contact = await Contact.findOne({ where: { number: phone, companyId } });
  if (!contact) {
    contact = await Contact.create({
      name: phone,
      number: phone,
      companyId,
      isGroup: false
    });
  }
  return contact;
};

const getOrCreateTicket = async (contactId: number, whatsappId: number, companyId: number) => {
  let ticket = await Ticket.findOne({
    where: {
      contactId,
      whatsappId,
      status: { [Op.ne]: "closed" }
    }
  });

  if (!ticket) {
    ticket = await Ticket.create({
      contactId,
      whatsappId,
      companyId,
      status: "pending",
      unreadMessages: 1,
      lastMessage: ""
    } as any);
  }

  return ticket;
};

export const processCloudWebhookPayload = async (payload: MetaWebhookPayload) => {
  const whatsapp = await resolveWhatsapp();
  if (!whatsapp) return { processed: 0, ignored: 0, reason: "no_whatsapp_connection" };

  let processed = 0;
  let ignored = 0;

  for (const entry of payload.entry || []) {
    for (const change of entry.changes || []) {
      for (const incoming of change.value?.messages || []) {
        const from = String(incoming.from || "").replace(/\D/g, "");
        const body = incoming.text?.body || "";
        const externalMsgId = incoming.id || "";
        const timestamp = Number(incoming.timestamp || 0);

        if (!from || !externalMsgId) {
          ignored += 1;
          continue;
        }

        try {
          const exists = await Message.findByPk(externalMsgId);
          if (exists) {
            recordInboundDuplicate();
            ignored += 1;
            continue;
          }

          const contact = await getOrCreateContact(from, whatsapp.companyId);
          const ticket = await getOrCreateTicket(contact.id, whatsapp.id, whatsapp.companyId);

          const createdAt = timestamp ? new Date(timestamp * 1000) : new Date();

          const message = await Message.create({
            id: externalMsgId || crypto.randomUUID(),
            body,
            contactId: contact.id,
            ticketId: ticket.id,
            fromMe: false,
            read: false,
            ack: 0,
            mediaType: incoming.type || "chat",
            createdAt,
            updatedAt: createdAt
          } as any);

          await ticket.update({
            lastMessage: body,
            unreadMessages: (ticket.unreadMessages || 0) + 1,
            updatedAt: new Date()
          } as any);

          try {
            await (contact as any).update({ leadStatus: "unread", lastInteractionAt: new Date() } as any);
          } catch {}

          recordInboundMessage({ fromMe: false, createdAt });
          console.log(`[wa-cloud][inbound] msgId=${message.id} ticketId=${ticket.id} from=${from}`);

          const io = getIO();
          io.to(`ticket-${ticket.id}`).emit("appMessage", {
            action: "create",
            message,
            ticket,
            contact
          });

          io.to("notification").emit("notification", {
            type: "new-message",
            ticketId: ticket.id,
            contactName: contact.name
          });

          processed += 1;
        } catch (error) {
          recordInboundError(error);
          console.error("[wa-cloud] error processing inbound:", error);
          ignored += 1;
        }
      }
    }
  }

  return { processed, ignored };
};

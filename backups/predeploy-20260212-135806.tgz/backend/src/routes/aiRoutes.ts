import { Router } from "express";
import { QueryTypes } from "sequelize";
import isAuth from "../middleware/isAuth";
import isAdmin from "../middleware/isAdmin";
import sequelize from "../database";

const aiRoutes = Router();

aiRoutes.get("/agents", isAuth, async (req: any, res) => {
  const { companyId } = req.user;
  const agents = await sequelize.query(
    `SELECT * FROM ai_agents WHERE company_id = :companyId ORDER BY id DESC`,
    { replacements: { companyId }, type: QueryTypes.SELECT }
  );
  return res.json(agents);
});

aiRoutes.post("/agents", isAuth, isAdmin, async (req: any, res) => {
  const { companyId } = req.user;
  const {
    name,
    persona,
    language = "es",
    model = "gpt-4o-mini",
    temperature = 0.3,
    maxTokens = 600,
    isActive = true,
    welcomeMsg = "",
    offhoursMsg = "",
    farewellMsg = "",
    businessHoursJson = "{}",
    funnelStagesJson = "[\"Nuevo\",\"Contactado\",\"Calificado\",\"Interesado\"]"
  } = req.body || {};

  const [row]: any = await sequelize.query(
    `INSERT INTO ai_agents
      (company_id, name, persona, language, model, temperature, max_tokens, is_active, welcome_msg, offhours_msg, farewell_msg, business_hours_json, funnel_stages_json, created_at, updated_at)
     VALUES
      (:companyId, :name, :persona, :language, :model, :temperature, :maxTokens, :isActive, :welcomeMsg, :offhoursMsg, :farewellMsg, :businessHoursJson, :funnelStagesJson, NOW(), NOW())
     RETURNING *`,
    {
      replacements: {
        companyId,
        name,
        persona,
        language,
        model,
        temperature,
        maxTokens,
        isActive,
        welcomeMsg,
        offhoursMsg,
        farewellMsg,
        businessHoursJson,
        funnelStagesJson
      },
      type: QueryTypes.INSERT
    }
  );

  return res.status(201).json(row);
});

aiRoutes.put("/agents/:id", isAuth, isAdmin, async (req: any, res) => {
  const { companyId } = req.user;
  const { id } = req.params;
  const fields = req.body || {};

  await sequelize.query(
    `UPDATE ai_agents
     SET
      name = COALESCE(:name, name),
      persona = COALESCE(:persona, persona),
      language = COALESCE(:language, language),
      model = COALESCE(:model, model),
      temperature = COALESCE(:temperature, temperature),
      max_tokens = COALESCE(:maxTokens, max_tokens),
      is_active = COALESCE(:isActive, is_active),
      welcome_msg = COALESCE(:welcomeMsg, welcome_msg),
      offhours_msg = COALESCE(:offhoursMsg, offhours_msg),
      farewell_msg = COALESCE(:farewellMsg, farewell_msg),
      business_hours_json = COALESCE(:businessHoursJson, business_hours_json),
      funnel_stages_json = COALESCE(:funnelStagesJson, funnel_stages_json),
      updated_at = NOW()
     WHERE id = :id AND company_id = :companyId`,
    {
      replacements: {
        id: Number(id),
        companyId,
        name: fields.name ?? null,
        persona: fields.persona ?? null,
        language: fields.language ?? null,
        model: fields.model ?? null,
        temperature: fields.temperature ?? null,
        maxTokens: fields.maxTokens ?? null,
        isActive: fields.isActive ?? null,
        welcomeMsg: fields.welcomeMsg ?? null,
        offhoursMsg: fields.offhoursMsg ?? null,
        farewellMsg: fields.farewellMsg ?? null,
        businessHoursJson: fields.businessHoursJson ?? null,
        funnelStagesJson: fields.funnelStagesJson ?? null
      },
      type: QueryTypes.UPDATE
    }
  );

  const [agent]: any = await sequelize.query(
    `SELECT * FROM ai_agents WHERE id = :id AND company_id = :companyId`,
    { replacements: { id: Number(id), companyId }, type: QueryTypes.SELECT }
  );

  return res.json(agent || null);
});

aiRoutes.post("/tickets/:ticketId/toggle-bot", isAuth, async (req: any, res) => {
  const { companyId } = req.user;
  const { ticketId } = req.params;
  const { botEnabled, humanOverride } = req.body || {};

  await sequelize.query(
    `UPDATE tickets
     SET bot_enabled = COALESCE(:botEnabled, bot_enabled),
         human_override = COALESCE(:humanOverride, human_override),
         updatedAt = NOW()
     WHERE id = :ticketId AND companyId = :companyId`,
    {
      replacements: {
        ticketId: Number(ticketId),
        companyId,
        botEnabled: typeof botEnabled === "boolean" ? botEnabled : null,
        humanOverride: typeof humanOverride === "boolean" ? humanOverride : null
      },
      type: QueryTypes.UPDATE
    }
  );

  const [ticket]: any = await sequelize.query(
    `SELECT id, status, bot_enabled, human_override FROM tickets WHERE id = :ticketId`,
    { replacements: { ticketId: Number(ticketId) }, type: QueryTypes.SELECT }
  );

  return res.json(ticket || null);
});

aiRoutes.post("/kb/documents", isAuth, async (req: any, res) => {
  const { companyId } = req.user;
  const { title, category = "faq", content = "" } = req.body || {};

  const [doc]: any = await sequelize.query(
    `INSERT INTO kb_documents (company_id, title, category, source_type, status, content, created_at, updated_at)
     VALUES (:companyId, :title, :category, 'manual', 'ready', :content, NOW(), NOW())
     RETURNING *`,
    { replacements: { companyId, title, category, content }, type: QueryTypes.INSERT }
  );

  // simple chunking by paragraphs
  const parts = String(content)
    .split(/\n{2,}/)
    .map((x) => x.trim())
    .filter(Boolean)
    .slice(0, 200);

  for (let i = 0; i < parts.length; i++) {
    await sequelize.query(
      `INSERT INTO kb_chunks (document_id, chunk_index, chunk_text, token_count, embedding_json, created_at, updated_at)
       VALUES (:documentId, :chunkIndex, :chunkText, :tokenCount, '[]', NOW(), NOW())`,
      {
        replacements: {
          documentId: doc.id,
          chunkIndex: i,
          chunkText: parts[i],
          tokenCount: Math.max(1, Math.floor(parts[i].length / 4))
        },
        type: QueryTypes.INSERT
      }
    );
  }

  return res.status(201).json({ document: doc, chunksCreated: parts.length });
});

aiRoutes.post("/rag/search", isAuth, async (req: any, res) => {
  const { companyId } = req.user;
  const { query = "", limit = 5 } = req.body || {};

  const rows = await sequelize.query(
    `SELECT c.id, c.document_id, c.chunk_text, d.title, d.category,
            (CASE WHEN POSITION(LOWER(:query) IN LOWER(c.chunk_text)) > 0 THEN 0.95 ELSE 0.50 END) AS score
     FROM kb_chunks c
     JOIN kb_documents d ON d.id = c.document_id
     WHERE d.company_id = :companyId
       AND (LOWER(c.chunk_text) LIKE LOWER(:qLike) OR LOWER(d.title) LIKE LOWER(:qLike))
     ORDER BY score DESC, c.id DESC
     LIMIT :limit`,
    {
      replacements: {
        companyId,
        query: String(query),
        qLike: `%${String(query)}%`,
        limit: Number(limit) || 5
      },
      type: QueryTypes.SELECT
    }
  );

  await sequelize.query(
    `INSERT INTO kb_search_logs (company_id, query, top_k, results_json, created_at, updated_at)
     VALUES (:companyId, :query, :topK, :resultsJson, NOW(), NOW())`,
    {
      replacements: {
        companyId,
        query: String(query),
        topK: Number(limit) || 5,
        resultsJson: JSON.stringify(rows)
      },
      type: QueryTypes.INSERT
    }
  );

  return res.json(rows);
});

aiRoutes.post("/tools/execute", isAuth, async (req: any, res) => {
  const { companyId, id: userId } = req.user;
  const { tool, args = {} } = req.body || {};

  const fail = (error: string, status = 400) => res.status(status).json({ ok: false, error });

  try {
    if (tool === "upsert_contact") {
      const number = String(args.number || "").replace(/\D/g, "");
      if (!number) return fail("number requerido");

      const [existing]: any = await sequelize.query(
        `SELECT * FROM contacts WHERE companyId = :companyId AND number = :number LIMIT 1`,
        { replacements: { companyId, number }, type: QueryTypes.SELECT }
      );

      if (existing) {
        await sequelize.query(
          `UPDATE contacts
           SET name = COALESCE(:name, name),
               email = COALESCE(:email, email),
               business_type = COALESCE(:businessType, business_type),
               needs = COALESCE(:needs, needs),
               updatedAt = NOW()
           WHERE id = :id`,
          {
            replacements: {
              id: existing.id,
              name: args.name ?? null,
              email: args.email ?? null,
              businessType: args.businessType ?? null,
              needs: args.needs ?? null
            },
            type: QueryTypes.UPDATE
          }
        );
      } else {
        await sequelize.query(
          `INSERT INTO contacts (name, number, email, isGroup, companyId, business_type, needs, lead_score, createdAt, updatedAt)
           VALUES (:name, :number, :email, false, :companyId, :businessType, :needs, :leadScore, NOW(), NOW())`,
          {
            replacements: {
              name: args.name || number,
              number,
              email: args.email || "",
              companyId,
              businessType: args.businessType || null,
              needs: args.needs || null,
              leadScore: Number(args.leadScore || 0)
            },
            type: QueryTypes.INSERT
          }
        );
      }

      return res.json({ ok: true, tool, result: "contact upserted" });
    }

    if (tool === "actualizar_lead_score") {
      const contactId = Number(args.contactId || 0);
      const leadScore = Math.max(0, Math.min(100, Number(args.leadScore || 0)));
      if (!contactId) return fail("contactId requerido");

      await sequelize.query(
        `UPDATE contacts SET lead_score = :leadScore, updatedAt = NOW() WHERE id = :contactId AND companyId = :companyId`,
        { replacements: { contactId, companyId, leadScore }, type: QueryTypes.UPDATE }
      );

      return res.json({ ok: true, tool, result: { contactId, leadScore } });
    }

    if (tool === "agregar_nota") {
      const ticketId = Number(args.ticketId || 0);
      const note = String(args.note || "").trim();
      if (!ticketId || !note) return fail("ticketId y note requeridos");

      await sequelize.query(
        `INSERT INTO ai_turns (conversation_id, role, content, model, latency_ms, tokens_in, tokens_out, created_at, updated_at)
         VALUES (NULL, 'tool', :content, 'manual-note', 0, 0, 0, NOW(), NOW())`,
        { replacements: { content: `[ticket:${ticketId}] ${note}` }, type: QueryTypes.INSERT }
      );

      return res.json({ ok: true, tool, result: "note saved" });
    }

    if (tool === "agendar_cita") {
      const contactId = Number(args.contactId || 0);
      const startsAt = String(args.startsAt || "");
      const durationMin = Number(args.durationMin || 30);
      if (!contactId || !startsAt) return fail("contactId y startsAt requeridos");

      const end = new Date(new Date(startsAt).getTime() + durationMin * 60_000).toISOString();

      const [appt]: any = await sequelize.query(
        `INSERT INTO appointments (company_id, contact_id, ticket_id, starts_at, ends_at, service_type, status, notes, created_at, updated_at)
         VALUES (:companyId, :contactId, :ticketId, :startsAt, :endsAt, :serviceType, 'scheduled', :notes, NOW(), NOW())
         RETURNING *`,
        {
          replacements: {
            companyId,
            contactId,
            ticketId: args.ticketId || null,
            startsAt,
            endsAt: end,
            serviceType: args.serviceType || "general",
            notes: args.notes || ""
          },
          type: QueryTypes.INSERT
        }
      );

      await sequelize.query(
        `INSERT INTO appointment_events (appointment_id, event_type, reason, created_by, created_at, updated_at)
         VALUES (:appointmentId, 'create', '', :createdBy, NOW(), NOW())`,
        { replacements: { appointmentId: appt.id, createdBy: userId }, type: QueryTypes.INSERT }
      );

      return res.json({ ok: true, tool, result: appt });
    }

    if (tool === "reprogramar_cita") {
      const appointmentId = Number(args.appointmentId || 0);
      const startsAt = String(args.startsAt || "");
      const durationMin = Number(args.durationMin || 30);
      if (!appointmentId || !startsAt) return fail("appointmentId y startsAt requeridos");

      const end = new Date(new Date(startsAt).getTime() + durationMin * 60_000).toISOString();

      await sequelize.query(
        `UPDATE appointments SET starts_at = :startsAt, ends_at = :endsAt, status='rescheduled', updated_at = NOW()
         WHERE id = :appointmentId AND company_id = :companyId`,
        { replacements: { appointmentId, companyId, startsAt, endsAt: end }, type: QueryTypes.UPDATE }
      );

      await sequelize.query(
        `INSERT INTO appointment_events (appointment_id, event_type, reason, created_by, created_at, updated_at)
         VALUES (:appointmentId, 'reschedule', :reason, :createdBy, NOW(), NOW())`,
        {
          replacements: { appointmentId, reason: String(args.reason || ""), createdBy: userId },
          type: QueryTypes.INSERT
        }
      );

      return res.json({ ok: true, tool, result: "appointment rescheduled" });
    }

    if (tool === "cancelar_cita") {
      const appointmentId = Number(args.appointmentId || 0);
      if (!appointmentId) return fail("appointmentId requerido");

      await sequelize.query(
        `UPDATE appointments SET status='cancelled', updated_at = NOW() WHERE id = :appointmentId AND company_id = :companyId`,
        { replacements: { appointmentId, companyId }, type: QueryTypes.UPDATE }
      );

      await sequelize.query(
        `INSERT INTO appointment_events (appointment_id, event_type, reason, created_by, created_at, updated_at)
         VALUES (:appointmentId, 'cancel', :reason, :createdBy, NOW(), NOW())`,
        {
          replacements: { appointmentId, reason: String(args.reason || ""), createdBy: userId },
          type: QueryTypes.INSERT
        }
      );

      return res.json({ ok: true, tool, result: "appointment cancelled" });
    }

    if (tool === "consultar_conocimiento") {
      const query = String(args.query || "");
      const rows = await sequelize.query(
        `SELECT c.chunk_text, d.title, d.category,
                (CASE WHEN POSITION(LOWER(:query) IN LOWER(c.chunk_text)) > 0 THEN 0.95 ELSE 0.50 END) AS similarity
         FROM kb_chunks c
         JOIN kb_documents d ON d.id = c.document_id
         WHERE d.company_id = :companyId
           AND LOWER(c.chunk_text) LIKE LOWER(:qLike)
         ORDER BY similarity DESC
         LIMIT 5`,
        { replacements: { companyId, query, qLike: `%${query}%` }, type: QueryTypes.SELECT }
      );

      return res.json({ ok: true, tool, result: rows });
    }

    return fail(`tool no soportada: ${tool}`);
  } catch (error: any) {
    return res.status(500).json({ ok: false, error: error?.message || "tool execution error" });
  }
});

export default aiRoutes;
